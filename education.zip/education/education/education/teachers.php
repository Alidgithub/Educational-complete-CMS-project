<div id="fh5co-staff">
		<div class="row">
			<div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box">
				<h2>Our Teacher</h2>
				<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
			</div>
			<?php
			$sql = "SELECT * FROM Teachers ORDER BY techer_id DESC";
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0 ) :
               	while($row = mysqli_fetch_assoc($result)):
             ?>
			<div class="col-md-3 text-center animate-box">
				<div class="staff">
					<div class="staff-img" style="background-image: url('admin/upload/teacher/<?php echo $row['img_url']; ?>');">
						<ul class="fh5co-social">
							<?php if( !empty($row['fb_link'])): ?>
								<li><a href="<?php echo $row['fb_link']; ?>" target='_blank' ><i class="icon-facebook2"></i></a></li>
							<?php endif?>
							<?php if( !empty($row['fb_link'])): ?>
							<li><a href="<?php echo $row['twitter_link']; ?>" target="_blank"><i class="icon-twitter2"></i></a></li>
							<?php endif?>
							
							<!-- <li><a href="#"><i class="icon-dribbble2"></i></a></li>
							<li><a href="#"><i class="icon-github"></i></a></li> -->
						</ul>
					</div>
					<span><?php echo $row['subject']; ?></span>
					<h3><a href="#"><?php echo $row['name']; ?></a></h3>
					<p><?php echo $row['about_himself']; ?></p>
				</div>
			</div>
		<?php endwhile ?>
		<?php endif ?>
		</div>
</div>