<?php
include "admin/action/config.php";

$sql = "SELECT * FROM photo_category ";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0 ) :

?>
<nav class="fh5co-nav" role="navigation">
	<div class="top-menu">
		<!-- <div class="container"> -->
			<div class="row">
				<div class="col-xs-12 text-left menu-1">
					<ul>
						<li class="active"><a href="gallery.php">All</a></li>
					<?php while ($row = mysqli_fetch_assoc($result)) : ?>
						

						<li><a href="gallery.php?c_id=<?php echo $row['id']; ?>"><?php echo $row['category_name']; ?></a></li>
				<?php endwhile ?>
					</ul>
				</div>
			</div>
			
		<!-- </div> -->
	</div>
</nav>
<?php endif ?>