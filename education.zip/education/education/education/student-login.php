<?php
session_start();
if (isset($_GET['smg'])) {
	$smg = $_GET['smg'];
}
?>

<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>log in</title>
		<link rel="stylesheet" type="text/css" href="css/style/Mycss.css">
		<link rel="stylesheet" type="text/css" href="css/style/all.min.css">
	</head>
	<body>
		<form method="post" action="action/student-action.php ">
			<div class="main_div1">


		<?php if (isset($_SESSION['ErrorAlert'])) {
			echo "<p style='text-align: center; color: red;'>". $_SESSION['ErrorAlert']."</p>";
			unset($_SESSION['ErrorAlert']);
		} 
		?>


			<?php if (isset($_GET['smg'])) : ?>
				<h3 style="text-align: center; color: red;"><?php echo $smg; ?></h3>
			<?php endif ?>
				<div class="main_div2">
					<img src="css/style/book.png" alt="book image (logo)">
					
				</div>
				<div class="main_div3">
					<h1>Only Student Login</h1>
					<input type="hidden" name="csrf_token">
					<p> <i class="fa-solid fa-user"></i> APPLICATION NO.</p>
					<input type="text" name="application" placeholder="Application no." >
					<p> <i class="fa-solid fa-lock"></i> PASSWORD</p>
					<input type="password" name="password" placeholder="Password" > 
					<!-- <p> <i class="fa-solid fa-user"></i> MOBILE NO.</p>
					<input type="text" name="mobile" placeholder="Mobile no." > -->
					<br> <br><br>
					
					<center>
					<button type ="submit" name="st_login">LOG IN</button>
					</center>
					<a href="#"><p class="forget_password">Forgotten Password</p></a>
				</div>
			</div>
		</form>
		
		
	</body>
</html>