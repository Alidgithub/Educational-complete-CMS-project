<?php
session_start();
include "admin/action/config.php" 
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Education &mdash; Free Website Template, Free HTML5 Template by freehtml5.co</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
		<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
		<meta name="author" content="freehtml5.co" />
		<meta property="og:title" content=""/>
		<meta property="og:image" content=""/>
		<meta property="og:url" content=""/>
		<meta property="og:site_name" content=""/>
		<meta property="og:description" content=""/>
		<meta name="twitter:title" content="" />
		<meta name="twitter:image" content="" />
		<meta name="twitter:url" content="" />
		<meta name="twitter:card" content="" />
		
		<!-- Animate.css -->
		<link rel="stylesheet" href="css/animate.css">
		<!-- Icomoon Icon Fonts-->
		<link rel="stylesheet" href="css/icomoon.css">
		<!-- Magnific Popup -->
		<link rel="stylesheet" href="css/magnific-popup.css">
		<!-- Owl Carousel  -->
		<link rel="stylesheet" href="css/owl.carousel.min.css">
		<link rel="stylesheet" href="css/owl.theme.default.min.css">
		<!-- Flexslider  -->
		<link rel="stylesheet" href="css/flexslider.css">
		<!-- Pricing -->
		<link rel="stylesheet" href="css/pricing.css">
		<!-- Theme style  -->
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/bootstrap.css">
		<!-- Modernizr JS -->
		<script src="js/modernizr-2.6.2.min.js"></script>
		
		<!-- FOR IE9 below -->
	</head>
	<body>

		
		<div class="fh5co-loader"></div>
		
		<div id="page">
			<?php include("include/header.php") ?>
			
			<aside id="fh5co-hero">
				<div class="flexslider">
					<ul class="slides">
						<li style="background-image: url(images/img_bg_4.jpg);">
							<div class="overlay-gradient"></div>
							<div class="row">
								<div class="col-md-8 col-md-offset-2 text-center slider-text">
									<div class="slider-text-inner">
										<h1 class="heading-section">Aplly Online</h1>
										<h2>Now we are connected with internet <a href="index.php">Home</a></h2>
									</div>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</aside>

			<div id="fh5co-contact">
				<!-- <div class="container"> -->
				<div class="row">

			<?php if (isset($_SESSION['ErrorAlert'])) : ?>
			<div class="alert alert-danger text-si" role="alert">
			 <strong> <?php echo $_SESSION['ErrorAlert'];
			 unset($_SESSION['ErrorAlert']);
			 ?>
			  </strong>
			</div>
		<?php endif ?>

					<form action="action/student-action.php" method="post" enctype="multipart/form-data">
						<div class="row form-group">
							<input type="hidden" name="csrf_token" value="">

							<div class="col-md-4">
								<label for="course">Choose your course :<span style="color: red;"> *</span></label>
								<select class="form-control" name="course" id="courses" onchange="one() ">
								<option  value=""> Select Category</option>

							<?php
							$sql = "SELECT course_id, course_name FROM courses ORDER BY course_id DESC";
                            $result = mysqli_query($conn, $sql);
                            if (mysqli_num_rows($result) > 0 ) {
                              
                            while ($row = mysqli_fetch_assoc($result)) { ?>
									<option value="<?php echo$row['course_id']; ?>"><?php echo $row['course_name']; ?></option>
			
								<?php } } ?>
								</select>
							</div>

							<div class="col-md-4">
								<label for="course">Admission Fees :<span style="color: red;"> *</span></label>
								<select class="form-control" name="admissionFees" id="admissionFees">
								</select>
							</div>

							<div class="col-md-4">
								<label for="course">Course duration :<span style="color: red;"> *</span></label>
								<select class="form-control" name="duration" id="duration">
								</select>
							</div>

							<div class="col-md-4">
								<label for="fname">Student Name :<span style="color: red;"> *</span></label>
								<input type="text" name="stName" id="fname" class="form-control" placeholder="Enter Student Name">
							</div>
							<div class="col-md-4">
								<label>Father's Name :<span style="color: red;"> *</span></label>
								<input type="text" name="fName" class="form-control" placeholder="Enter Father's Name">
							</div>
							<div class="col-md-4">
								<label>Date of Birth :<span style="color: red;"> *</span></label>
								<input type="date" name="birth" class="form-control" required>
							</div>
							<div class="col-md-4">
								<label for="lname">Religion :</label>
								<input type="text" name="religion" class="form-control" placeholder="Enter Religion">
							</div>
							<div class="col-md-4">
								<label for="lname">Email :<span style="color: red;"> *</span></label>
								<input type="email" name="email" id="lname" class="form-control" placeholder="Enter Email">
							</div>
							
							<div class="col-md-4">
								<label for="lname">Aadhaar No. :<span style="color: red;"> *</span></label>
								<input type="number" name="aadhaar" id="lname" class="form-control" placeholder="Enter Aadhaar No.">
							</div>
							<div class="col-md-4">
								<label for="lname">Caste :</label>
								<input type="text" name="caste" id="lname" class="form-control" placeholder="ST/SC/OBC">
							</div>
							<div class="col-md-4">
								<label for="lname">Highest Qualification :<span style="color: red;"> *</span></label>
								<input type="text" name="qualification" id="lname" class="form-control" placeholder="M.P / H.S / M.A / B.A">
							</div>
							<div class="col-md-4">
								<label>Marks %<span style="color: red;"> *</span></label>
								<input type="number" name="marks" id="email" class="form-control" placeholder=" Marks">
							</div>
							


						</div>
						<div class="row form-group">
							<div class="col-md-8">
								<label for="text">Address with pin code <span style="color: red;"> *</span></label>
								<input type="text" name="address" id="email" class="form-control" placeholder="Full Address">
							</div>
							<div class="col-md-4">
								<label for="photo">Photo copy <span style="color: red;"> *</span></label>
								<input type="file" name="stPhoto" id="email" class="form-control" placeholder="Your email address">
							</div>


							<div class="col-md-4">
								<p><b>Gender : <span style="color: red;"> *</span></b></p>
								<label>
								<input type="radio" checked name="gender" value="male"> Male
								</label>
								<label>
								<input type="radio" name="gender" value="female"> Female
								</label>
							</div>

							
							<div class="col-md-4">
								<label for="lname">Captcha <span style="color: red;"> *</span></label>
								<img id="captcha" src="captcha/captcha.php" style="margin-top: 10px; height: 50px;">
								<a id='reload' style="cursor: pointer;">Refresh now</a>

								
							</div>
							<div class="col-md-4">
								<label for="lname">Enter Captcha <span style="color: red;"> *</span></label>
								<input type="number" name="captcha" class="form-control" placeholder="Captcha">
							</div>

							<div class="col-md-4">
								<label for="lname">Mobile No. :<span style="color: red;"> *</span></label>
								<input type="number" name="mobile" id="mobile" class="form-control" placeholder="Enter Mobile No.">
							</div>

							<div class="col-md-2">
								<input type="button" name="sendOtp" value="Send OTP" class="btn btn-primary" style="margin-top: 23px;" id="sendOtp" onclick="sendOTP()">
							</div>

							<div class="col-md-2">
								<label for="lname">OTP<span style="color: red;"> *</span></label>
								<input type="number" name="otp" id="lname" class="form-control" placeholder="Enter OTP here.">
							</div>
							
						</div>
					</div>
					<div class="form-group">
						<input type="submit" name="stInfo" value="Apply" class="btn btn-primary">
						<input type="reset" value="Reset" class="btn btn-primary">
					</div>
				</form>
			</div>
			
			<!-- </div> -->
		</div>
		<?php include("include/footer.php") ?>
	</div>
	
	<!-- jQuery -->
	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<!-- Stellar Parallax -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Carousel -->
	<script src="js/owl.carousel.min.js"></script>
	<!-- Flexslider -->
	<script src="js/jquery.flexslider-min.js"></script>
	<!-- countTo -->
	<script src="js/jquery.countTo.js"></script>
	<!-- Magnific Popup -->
	<script src="js/jquery.magnific-popup.min.js"></script>
	<script src="js/magnific-popup-options.js"></script>
	<!-- Google Map -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>
	<script src="js/google_map.js"></script>
	<!-- Count Down -->
	<script src="js/simplyCountdown.js"></script>
	<!-- Main -->
	<script src="js/main.js"></script>
	<script src="js/googleApi.js"></script>
	<script src="js/fetch_data.js"></script>
  

</body>
</html>