<?php 
// session_start(); 
// if (isset($_SESSION['username'])) {
//     header("location: admin/users.php");
// }

?>

<div class="container">
<nav class="fh5co-nav" role="navigation">
  <div class="top">
      <div class="row">
        <div class="col-xs-12 text-right">
          <p class="site"><b>Email :</b> alidsk4@gmail.com</p>
          <p class="num">Call: +91 808 967 4601</p>
          <ul class="fh5co-social">
            <li><a href="#"><i class="icon-facebook22"></i></a></li>
            <li><a href="#"><i class="icon-twitter22"></i></a></li>
            <li><a href="#"><i class="icon-whatsapp"></i></a></li>
            <!-- <li><a href="#"><i class="icon-github"></i></a></li> -->
          </ul>
        </div>
      </div>
  </div>
  <div class="top-menu">
      <div class="row">
        <div class="col-xs-12">
          <div id="fh5co-logo"><a href="index.php"><i class="icon-study"></i><span class="text-info">কুলি চৌরাস্তা কলেজ অফ এডুকেশন</span></a>

            <div style="float: right; margin-right: 20px;">
          <ul>
          <li class="btn-cta"><a href="student-login.php"><span style="color: white; ">Login here</span></a></li>
        </ul>
            </div>
        </div>
        <br>
      </div>
    </div>
    <div class="row">
      <div class="col-xs-12 text-right menu-1">
        <ul>
          <li class="active"><a href="index.php">Home</a></li>
          <li><a href="rules.php">Rules & Regulation</a></li>
          <li class="has-dropdown">
            <a href="#">Facilities</a>
            <ul class="dropdown">
              <li><a href="laboratory.php">Laboratory</a></li>
              <li><a href="management.php">Management</a></li>
              <li><a href="events.php">Social Events</a></li>
            </ul>
          </li>
          <li class="has-dropdown">
            <a href="#">Students</a>
            <ul class="dropdown">
              <li><a href="apply_form.php">Online Aplication</a></li>
              <li><a href="#">Aplication Stutus</a></li>
              <li><a href="#">Verification</a></li>
              <li><a href="#">Result</a></li>
              <li><a href="#">Online Payment</a></li>
            </ul>
          </li>
          <li><a href="teacher_menu.php">Teachers</a></li>
          <li><a href="gallery.php">Gellary</a></li>
          <li><a href="courses.php">Courses</a></li>
          
          <li class="has-dropdown">
            <a href="#">Documents</a>
            <ul class="dropdown">
              <li><a href="#">Web Design</a></li>
              <li><a href="#">eCommerce</a></li>
              <li><a href="#">Branding</a></li>
              <li><a href="#">API</a></li>
            </ul>
          </li>
          <li><a href="about.php">About Us</a></li>
          <li><a href="contact.php">Contact</a></li>
          <li class="btn-cta"><a href="apply_form.php"><span>Apply now</span></a></li>

        </ul>
      </div>
    </div>
</div>
</nav>