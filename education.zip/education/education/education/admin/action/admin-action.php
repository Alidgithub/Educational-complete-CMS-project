<?php
session_start();
include"config.php";
function sanitize_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

function ErrorAlert($msg){
  $_SESSION['ErrorAlert'] = $msg;
}

function SuccessAlert($messege){
  $_SESSION['SuccessAlert'] = $messege;
}

function validate_mobile($num){
    return preg_match('/^[6-9]\d{9}$/', $num);
}

// function compressedImage($source, $path, $quality) {

//   $info = getimagesize($source);

//   if ($info['mime'] == 'image/jpeg') 
//     $image = imagecreatefromjpeg($source);

//   elseif ($info['mime'] == 'image/gif') 
//     $image = imagecreatefromgif($source);

//   elseif ($info['mime'] == 'image/png') 
//    $image = imagecreatefrompng($source);

//   imagejpeg($image, $path, $quality);
//   return $path;
// }



//Add users//

if (isset($_POST['save'])) {
    $fname = mysqli_real_escape_string($conn, sanitize_input($_POST['fname']));
    $lname = mysqli_real_escape_string($conn, sanitize_input($_POST['lname']));
    $user = mysqli_real_escape_string($conn, sanitize_input($_POST['user']));
    $password = mysqli_real_escape_string($conn, sanitize_input($_POST['password']));
    $role = mysqli_real_escape_string($conn, sanitize_input($_POST['role']));

   if (!isset($fname) || empty($fname)) {
        // header("Location: ../add-user.php");
        ErrorAlert("First name is required.");
        echo '<script>window.history.back();</script>';
        die();
      }
    if (!preg_match("/^[a-zA-Z-' ]*$/", $fname)) {
       // header("Location: ../add-user.php"); 
       ErrorAlert("Only letters and white space allowed.");
        echo '<script>window.history.back();</script>';
       die();
      }
    if(!isset($lname) || empty($lname)){
        // header("Location: ../add-user.php");
        ErrorAlert("Last Name is required.");
         echo '<script>window.history.back();</script>';
        die();
      }
    if (!preg_match("/^[a-zA-Z-' ]*$/", $lname)) {
     // header("Location: ../add-user.php");
     ErrorAlert("Only letters and white space allowed.");
      echo '<script>window.history.back();</script>';

     die(); 
    }
    if(!isset($user) || empty($user)){
      // header("Location: ../add-user.php");
      ErrorAlert("Username is required.");
       echo '<script>window.history.back();</script>';
      die();
    }
    if(!isset($password) || empty($password)){
      // header("Location: ../add-user.php");
      ErrorAlert("Password is required.");
      echo '<script>window.history.back();</script>';
      die();
    }

    $sql = "SELECT username FROM admin_login WHERE username = '$user'";
    $result = mysqli_query($conn, $sql) or die("Query Failed");
    if (mysqli_num_rows($result) > 0 ) {
      header("Location: ../add-user.php");
      ErrorAlert("Username Already Exists.");
      die();
    }else{
      $password = md5($password);
      $sql1 = "INSERT INTO `admin_login`(first_name, last_name, username, password,role) 
               VALUES ('$fname','$lname','$user','$password','$role')";

        $result1 = mysqli_query($conn,$sql1);
        if ($result1) {
           header("Location: ../users.php");
           SuccessAlert("User added sucessfull");
          }
    }
}





//Admin Login//

// Set the maximum number of login attempts
$max_login_attempts = 3;

// Set the lockout time in seconds
$lockout_time = 300; // 5 minutes

// Check if the user has exceeded the maximum login attempts
if (isset($_SESSION['login_attempts']) && $_SESSION['login_attempts'] >= $max_login_attempts) {
    // Check if the lockout time has expired
    if (isset($_SESSION['lockout_time']) && time() < $_SESSION['lockout_time']) {
        // Lockout time has not expired, redirect to error page
        header("Location: ../index.php");
        ErrorAlert("Your account has been temporarily locked. Please try again later.");
        exit();
    } else {
        // Lockout time has expired, reset login attempts
        unset($_SESSION['login_attempts']);
        unset($_SESSION['lockout_time']);
    }
}
// Process login attempt
if (isset($_POST['login'])) {
    if (isset($_POST['username']) && isset($_POST['password'])) {
        $username = mysqli_real_escape_string($conn, sanitize_input($_POST['username']));
        $password = mysqli_real_escape_string($conn, sanitize_input($_POST['password']));

        if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !=  $_SESSION['token']){
          header("Location: ../index.php");
          ErrorAlert("csrf token missing or not match");
        }else{

            if (empty($username)) {
                header("Location: ../index.php");
                ErrorAlert("Username is required");
            } elseif (empty($password)) {
                header("Location: ../index.php");
                ErrorAlert("Password is required");
            } else {
              $password = md5($password);
                $sql = "SELECT * FROM admin_login WHERE username = '$username' AND password = '$password'";
                $result = mysqli_query($conn, $sql) or die("Query Failed");
                if (mysqli_num_rows($result) > 0) {
                    // Login successful, reset login attempts
                    unset($_SESSION['login_attempts']);
                    unset($_SESSION['lockout_time']);
                    $row = mysqli_fetch_assoc($result);
                    $_SESSION['first_name'] = $row['first_name'];
                    $_SESSION['username'] = $row['username'];
                    $_SESSION['role'] = $row['role'];
                    $_SESSION['id'] = $row['id'];
                    header("Location: ../users.php");
                    SuccessAlert("Welcome to Admin Pannel");
                } else {
                    // Login failed, increment login attempts
                    if (!isset($_SESSION['login_attempts'])) {
                        $_SESSION['login_attempts'] = 1;
                    } else {
                        $_SESSION['login_attempts']++;
                    }
                    // Set lockout time if max login attempts exceeded
                    if ($_SESSION['login_attempts'] >= $max_login_attempts) {
                        $_SESSION['lockout_time'] = time() + $lockout_time;
                    }
                    header("Location: ../index.php");
                    ErrorAlert("Username and Password is incorrect");
                }
            }
        }
  }
}





//update user//

if (isset($_POST['submit']) && isset($_POST['user_id'])) {
 $userId = $_POST['user_id'];
 $fname = mysqli_real_escape_string($conn, sanitize_input($_POST['f_name']));
    $lname = mysqli_real_escape_string($conn, sanitize_input($_POST['l_name']));
    $user = mysqli_real_escape_string($conn, sanitize_input($_POST['username']));
    $password = mysqli_real_escape_string($conn, sanitize_input($_POST['password']));
    $role = mysqli_real_escape_string($conn, sanitize_input($_POST['role']));

 if (!isset($fname) || empty($fname)) {
        header("Location: ../update-user.php?id=".$userId);
        ErrorAlert("First name is required.");
        die();
      }
    if (!preg_match("/^[a-zA-Z-' ]*$/", $fname)) {
       header("Location: ../update-user.php?id=".$userId); 
       ErrorAlert("Only letters and white space allowed.");
       die();
      }
    if(!isset($lname) || empty($lname)){
        header("Location: ../update-user.php?id=".$userId);
        ErrorAlert("Last Name is required.");
        die();
      }
    if (!preg_match("/^[a-zA-Z-' ]*$/", $lname)) {
     header("Location: ../update-user.php?id=".$userId);
     ErrorAlert("Only letters and white space allowed.");
     die(); 
    }
    if(!isset($user) || empty($user)){
      header("Location: ../update-user.php?id=".$userId);
      ErrorAlert("Username is required.");
      die();
    }
    if(!isset($password)){
      header("Location: ../update-user.php?id=".$userId);
      ErrorAlert("Password is not set.");
      die();
    }

 $sql2 = "UPDATE admin_login SET first_name = '$fname', last_name = '$lname', username = '$user', role = '$role' ";

if(!empty($password)){
    $password = md5($password);
    $sql2 .= ", password = '$password' ";
}
 $sql2.= " WHERE id = '$userId' ";
  $result2 = mysqli_query($conn, $sql2);
  if ($result2) {
    header("Location: ../users.php");
    SuccessAlert("User details updated sucessfull");
  }
}


//add notice//

if (isset($_POST['add_notice'])) {
  $notice_title = mysqli_real_escape_string($conn, sanitize_input($_POST['notice_title']));
  $notice_date = mysqli_real_escape_string($conn, date("Y-m-d",strtotime($_POST['notice_date'])));
  $notice_description = mysqli_real_escape_string($conn, sanitize_input($_POST['notice_description']));

  if (!isset($notice_title) || empty($notice_title)) {
    // header("Location: ../add-notice.php");
    echo '<script>window.history.back()</script>';
    ErrorAlert("Title is required");
    die();
  }
  if ((!isset($notice_date) || empty($notice_date)) || $notice_date == '1970-01-01') {
    // header("Location: ../add-notice.php");
    echo '<script>window.history.back();</script>';
    ErrorAlert("Date is required");
    die();
  }
  if (!isset($notice_description) || empty($notice_description)) {
    // header("Location: ../add-notice.php");
    ErrorAlert("Description is required");
    echo '<script>window.history.back();</script>';
    die();
  }

  $sql3 = "SELECT tittle FROM notice WHERE tittle = '$notice_title' ";
  $result3 = mysqli_query($conn, $sql3) or die("Query Failed");
  if (mysqli_num_rows($result3) > 0 ) {
    // header("Location: ../add-notice.php");
    ErrorAlert("Tittle is Already Exists");
    echo '<script>window.history.back();</script>';
    die();
  }else{
    $sql4 = "INSERT INTO notice (tittle, description, noticeDate)
             VALUES('$notice_title',' $notice_description', '$notice_date')";
    $result4 = mysqli_query($conn, $sql4);
    if ($result4) {
      header("Location: ../notice.php");
      SuccessAlert("Your Notice Added sucessfully");
      die();
    }
  }

}


//update notice//
if (isset($_POST['update_notice'])) {
  $notice_id = $_POST['notice_id'];
  $update_notice_title = mysqli_real_escape_string($conn, sanitize_input($_POST['update_notice_title']));
  $update_notice_date = mysqli_real_escape_string($conn, date("Y-m-d",strtotime($_POST['update_notice_date'])));
  $update_notice_description = mysqli_real_escape_string($conn, sanitize_input($_POST['update_notice_description']));
  

  if (!isset($update_notice_title) || empty($update_notice_title)) {
    header("Location: ../update-notice.php?notice_id=".$notice_id);
    ErrorAlert("Tittle is required");
    die();
  }
  // if (!isset($notice_date) || empty($notice_date)) {
  //   header("Location: ../add-notice.php");
  //   ErrorAlert("Date is required");
  //   die();
  // }
  if (!isset($update_notice_description) || empty($update_notice_description)) {
    header("Location: ../update-notice.php?notice_id=".$notice_id);
    ErrorAlert("Description is required");
    die();
  }

  $sql5 = "UPDATE notice SET tittle = '$update_notice_title', description = '$update_notice_description', noticeDate = '$update_notice_date' WHERE id = '$notice_id' ";
  $result5 = mysqli_query($conn, $sql5);
  if ($result5) {
    header("Location: ../notice.php?notice_id=".$notice_id);
    SuccessAlert("Notice details updated sucessfull.");
  }
}



//Add Photo category//

if (isset($_POST['submit_photo_category'])) {
  $photo_category = mysqli_real_escape_string($conn, sanitize_input($_POST['category']));

  if (!isset($photo_category) || empty($photo_category)) {
    header("Location: ../add-photo-category.php");
    ErrorAlert("Category name is required");
    // echo '<script>window.history.back();</script>';
    die();
  }
  if (!preg_match("/^[a-zA-Z-' ]*$/", $photo_category)) {
     // header("Location: ../add-photo-category.php");
     ErrorAlert("Only letters and white space allowed.");
    echo '<script>window.history.back();</script>';
     die(); 
    }

    $sql6 = "SELECT category_name FROM photo_category WHERE category_name = '$photo_category' ";
    $result6 = mysqli_query($conn, $sql6);
    if (mysqli_num_rows($result6) > 0 ) {
      echo '<script>window.history.back();</script>';
      ErrorAlert("Category name Already Exists");
    }else{
      $sql7 = "INSERT INTO photo_category(category_name) VALUES('$photo_category') ";
      $result7 = mysqli_query($conn, $sql7);
      if ($result7) {
        header("Location: ../photo-category.php");
        SuccessAlert("upload Your Category name sucessfully");
      }
    }
}

//update Photo category//

if (isset($_POST['update_photo_category'])) {
  $update_category = mysqli_real_escape_string($conn, sanitize_input($_POST['cat']));
  $categoryid = mysqli_real_escape_string($conn, sanitize_input($_POST['cat_id']));

  if (!isset($update_category) || empty($update_category)) {
    header("Location: ../update-photo-category.php?id=".$categoryid);
    ErrorAlert("Category name is required");
    die();
  }
  if (!preg_match("/^[a-zA-Z-' ]*$/", $update_category)) {
     header("Location: ../update-photo-category.php?id=".$categoryid);
     ErrorAlert("Only letters and white space allowed.");
     die(); 
    }

    $sql9 = "SELECT category_name FROM photo_category WHERE category_name = '$update_category' "; 
    $result9 = mysqli_query($conn, $sql9);
    if (mysqli_num_rows($result9) > 0 ) {
      header("Location: ../update-photo-category.php?id=".$categoryid);
      ErrorAlert("Category name is Already Exists");
      die();
    }else{
    $sql8 = "UPDATE  photo_category SET category_name = '$update_category' WHERE id = '$categoryid' ";
    $result8 = mysqli_query($conn, $sql8);
      if ($result8) {
        header("Location: ../photo-category.php");
        SuccessAlert("Category name updated sucessfully");
      }
    }
    
}


//Add photos//

if (isset($_POST['addImage']) && isset($_FILES['fileToUpload'])) {
  $image_titttle = mysqli_real_escape_string($conn, sanitize_input($_POST['image_title']));
  $image_category = mysqli_real_escape_string($conn, sanitize_input($_POST['category']));

  $file_name = mysqli_real_escape_string($conn, sanitize_input($_FILES['fileToUpload']['name']));
  $file_size = $_FILES['fileToUpload']['size'];
  $file_tmp = $_FILES['fileToUpload']['tmp_name'];
  $file_type = $_FILES['fileToUpload']['type'];
  $file_error = $_FILES['fileToUpload']['error'];

  // echo $image_titttle;
  // exit();

  if (!isset($image_titttle) || empty($image_titttle)) {
       // header("Location: ../add-photo.php");
       echo '<script>window.history.back();</script>';
       ErrorAlert("Image titttle is required");
       die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $image_titttle)) {
     echo '<script>window.history.back();</script>';
     ErrorAlert("Only letters and white space allowed.");
     die(); 
  }

  if (!isset($image_category) || empty($image_category)) {
     echo '<script>window.history.back();</script>';
     ErrorAlert("Catagory is required.");
     die(); 
  }

  if (empty($file_name)) {
    echo '<script>window.history.back();</script>';
    ErrorAlert("Image is required");
    die();
  }

  $file_txt = explode(".", $file_name);
  $file_txt = end($file_txt);
  $file_txt = strtolower($file_txt);
  $extensions = ["jpg","jpeg","png"];

  if (in_array($file_txt, $extensions) == false) {
       // header("Location: ../add-photo.php");
       echo '<script>window.history.back();</script>';
       ErrorAlert("Please choose an jpg or png format");
       die();
  }

  if ($file_size > 1000000) {
       echo '<script>window.history.back();</script>';
      ErrorAlert("File size must be less than 1MB.");
      die();
    }

  $new_file = time()."-". basename($file_name);
  $terget = "../upload/".$new_file;
  move_uploaded_file($file_tmp, $terget);

  $sql = "INSERT INTO gallery(tittle, photo_cat_id, image_url) 
          VALUES('$image_titttle', '$image_category' , '$new_file') ;";
  $sql .= "UPDATE photo_category SET total_images =  total_images +1 WHERE id = '$image_category'";

  $result = mysqli_multi_query($conn, $sql);
  if ($result) {
    header("Location: ../photo.php");
    SuccessAlert("Image added sucessfully.");
  }else{
    ErrorAlert("something is wrong");
  }


}

//update gallery//

if (isset($_POST['update_img'])) {
  $img_id = mysqli_real_escape_string($conn, sanitize_input($_POST['post_img_id']));
  $category = mysqli_real_escape_string($conn, sanitize_input($_POST['category']));
  $image_title = mysqli_real_escape_string($conn, sanitize_input($_POST['image_title']));
  $old_img = mysqli_real_escape_string($conn, sanitize_input($_POST['old_image']));

  $file_name = mysqli_real_escape_string($conn, sanitize_input($_FILES['new_image']['name'])); 
  $file_type = $_FILES['new_image']['type'];
  $file_error = $_FILES['new_image']['error'];
  $file_size = $_FILES['new_image']['size'];
  $tmp_name = $_FILES['new_image']['tmp_name'];

  if (!isset($image_title) || empty($image_title)) {
    header("Location: ../update-photo.php?img_id=".$img_id);
    ErrorAlert("Tittle is required.");
    die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $image_title)) {
     header("Location: ../update-photo.php?img_id=".$img_id);
     ErrorAlert("Only letters and white space allowed.");
     die(); 
  }

  if (isset($file_name) && empty($file_name)) {
    $new_file = $old_img;
    header("Location: ../photo.php");
  }else{
    $allowedType = explode(".",$file_name);
    $allowedType = end($allowedType);
    $allowedType = strtolower($allowedType);
    $extensions = ["jpg", "jpeg", "png"];

    if (!in_array($allowedType, $extensions)) {
      header("Location: ../update-photo.php?img_id=".$img_id);
      ErrorAlert("Please choose an jpg or png format");
      die();
    }
    if ($file_size > 1000000) {
      header("Location: ../update-photo.php?img_id=".$img_id);
      ErrorAlert("File size must be less than 1MB.");
      die();
    }

    $new_file = time()."-". basename($file_name); 
    $target = "../upload/".$new_file;
    move_uploaded_file($tmp_name, $target);
    unlink("../upload/".$old_img);
  }
       $sql = "UPDATE gallery SET tittle = '$image_title', photo_cat_id = '$category', image_url = '$new_file' WHERE photo_id = '$img_id' ";
      $result = mysqli_query($conn, $sql);
      if ($result) {
        header("Location: ../photo.php");
      }
  
}




//Add Slider//
if (isset($_POST['addSlider']) && isset($_FILES['slider_img'])) {
  $tittle = mysqli_real_escape_string($conn, sanitize_input($_POST['title']));
  $sub_tittle = mysqli_real_escape_string($conn, sanitize_input($_POST['sub_title']));
  date_default_timezone_set("Asia/Kolkata");
  $uploading_date = date(" Y-m-d H:i:s");

  $file_name = mysqli_real_escape_string($conn, sanitize_input($_FILES['slider_img']['name']));
  $file_size = $_FILES['slider_img']['size'];
  $file_tmp = $_FILES['slider_img']['tmp_name'];
  $file_type = $_FILES['slider_img']['type'];
  $file_error = $_FILES['slider_img']['error'];

  if (!isset($tittle) || empty($tittle)) {
       // header("Location: ../add-photo.php");
       echo '<script>window.history.back();</script>';
       ErrorAlert("tittle is required");
       die();
  }

  if (!isset($sub_tittle) || empty($sub_tittle)) {
     echo '<script>window.history.back();</script>';
     ErrorAlert("Sub-tittle is required.");
     die(); 
  }

  if (empty($file_name)) {
    echo '<script>window.history.back();</script>';
    ErrorAlert("Image is required");
    die();
  }

  $file_txt = explode(".", $file_name);
  $file_txt = end($file_txt);
  $file_txt = strtolower($file_txt);
  $extensions = ["jpg","jpeg","png"];

  if ($file_size > 1000000) {
       echo '<script>window.history.back();</script>';
      ErrorAlert("File size must be less than 1MB.");
      die();
    }

  if (in_array($file_txt, $extensions) == false) {
       // header("Location: ../add-photo.php");
       echo '<script>window.history.back();</script>';
       ErrorAlert("Please choose an jpg or png format");
       die();
  }


  $new_file = time()."-". basename($file_name);
  $terget = "../upload/".$new_file;
  move_uploaded_file($file_tmp, $terget);

  $sql = "INSERT INTO slider(tittle, sub_tittle, date, img_url) 
          VALUES('$tittle', '$sub_tittle', '$uploading_date' , '$new_file')";

  $result = mysqli_query($conn, $sql);
  if ($result) {
    header("Location: ../slider.php");
    SuccessAlert("Slider added sucessfully.");
  }else{
    ErrorAlert("something is wrong");
  }


}




//update slider//
if (isset($_POST['update_slider'])) {
  $sliderId = mysqli_real_escape_string($conn, sanitize_input($_POST['sliderId']));
  $tittle = mysqli_real_escape_string($conn, sanitize_input($_POST['tittle']));
  $sub_tittle = mysqli_real_escape_string($conn, sanitize_input($_POST['sub_tittle']));
  $old_image = mysqli_real_escape_string($conn, sanitize_input($_POST['old_image']));
  date_default_timezone_set("Asia/Kolkata");
  $update_date = date(" Y-m-d H:i:s");


  $file_name = mysqli_real_escape_string($conn, sanitize_input($_FILES['new_image']['name'])); 
  $file_type = $_FILES['new_image']['type'];
  $file_error = $_FILES['new_image']['error'];
  $file_size = $_FILES['new_image']['size'];
  $tmp_name = $_FILES['new_image']['tmp_name'];

  if (!isset($tittle) || empty($tittle)) {
    header("Location: ../update-slider.php?sliderId=".$sliderId);
    ErrorAlert("Tittle is required.");
    die();
  }

  if (!isset($sub_tittle) || empty($sub_tittle)) {
    header("Location: ../update-slider.php?sliderId=".$sliderId);
    ErrorAlert("Tittle is required.");
    die();
  }

  if (isset($file_name) && empty($file_name)) {
    $new_file = $old_image;
    header("Location: ../slider.php");
  }else{
    $allowedType = explode(".",$file_name);
    $allowedType = end($allowedType);
    $allowedType = strtolower($allowedType);
    $extensions = ["jpg", "jpeg", "png"];

    if (!in_array($allowedType, $extensions)) {
      header("Location: ../update-slider.php?sliderId=".$sliderId);
      ErrorAlert("Please choose an jpg or png format");
      die();
    }
    if ($file_size > 3000000) {
      header("Location: ../update-slider.php?sliderId=".$sliderId);
      ErrorAlert("File size must be less than 3MB.");
      die();
    }

    $new_file = time()."-". basename($file_name); 
    $target = "../upload/".$new_file;
    move_uploaded_file($tmp_name, $target);
    unlink("../upload/".$old_image);
  }
       $sql = "UPDATE slider SET tittle = '$tittle', sub_tittle = '$sub_tittle', date = '$update_date', img_url = '$new_file' WHERE slider_id = '$sliderId' ";
      $result = mysqli_query($conn, $sql);
      if ($result) {
        header("Location: ../slider.php");
        SuccessAlert("Slider updated sucessfully.");
      }
  
}





//add management//
if (isset($_POST['addDesignation'])) {
  $name = mysqli_real_escape_string($conn, sanitize_input($_POST['name']));
  $designation = mysqli_real_escape_string($conn, sanitize_input($_POST['designation']));
  $mobile = mysqli_real_escape_string($conn, sanitize_input($_POST['mobile']));

  if (!isset($name) || empty($name)) {
    // header("Location: ../add-notice.php");
    echo '<script>window.history.back()</script>';
    ErrorAlert("Name is required");
    die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
    echo '<script>window.history.back()</script>';
   ErrorAlert("Only letters and white space allowed.");
   die(); 
  }

  if (!isset($designation) || empty($designation)) {
    // header("Location: ../add-notice.php");
    echo '<script>window.history.back();</script>';
    ErrorAlert("Designation is required");
    die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $designation)) {
    echo '<script>window.history.back()</script>';
   ErrorAlert("Only letters and white space allowed.");
   die(); 
  }


  if (!isset($mobile) || empty($mobile)) {
    // header("Location: ../add-notice.php");
    ErrorAlert("Mobile is required");
    echo '<script>window.history.back();</script>';
    die();
  }

  // if (!is_numeric($mobile)) {
  //     ErrorAlert("Please type only numbers.");
  //   echo '<script>window.history.back();</script>';
  //   die();
  //   }


    if(!validate_mobile($mobile)){
        ErrorAlert("Please type only numbers.");
        echo '<script>window.history.back();</script>';
        die();
    }

    $countNumber = strlen($mobile);
      if ($countNumber != 10) {
      ErrorAlert("please enter 10 digit mobile no.");
      echo '<script>window.history.back();</script>';
      die();
    }

    $sql4 = "INSERT INTO management (name, desig, mobile)
             VALUES('$name',' $designation', '$mobile')";
    $result4 = mysqli_query($conn, $sql4);
    if ($result4) {
      header("Location: ../management.php");
      SuccessAlert("Your management Added sucessfully");
      die();
    }
  

}



//update management//
if (isset($_POST['update_management'])) {
  $manage_id = mysqli_real_escape_string($conn, sanitize_input($_POST['manage_id']));
  $name = mysqli_real_escape_string($conn, sanitize_input($_POST['name']));
  $designation = mysqli_real_escape_string($conn, sanitize_input($_POST['designation']));
  $mobile = mysqli_real_escape_string($conn, sanitize_input($_POST['mobile']));

  if (!isset($name) || empty($name)) {
    header("Location: ../update-management.php?managId=".$manage_id);
    // echo '<script>window.history.back()</script>';
    ErrorAlert("Name is required");
    die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
   header("Location: ../update-management.php?managId=".$manage_id);
   ErrorAlert("Only letters and white space allowed.");
   die(); 
  }

  if (!isset($designation) || empty($designation)) {
    header("Location: ../update-management.php?managId=".$manage_id);
    ErrorAlert("Designation is required");
    die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $designation)) {
   header("Location: ../update-management.php?managId=".$manage_id);
   ErrorAlert("Only letters and white space allowed.");
   die(); 
  }


  if (!isset($mobile) || empty($mobile)) {
    // header("Location: ../add-notice.php");
    header("Location: ../update-management.php?managId=".$manage_id);
    ErrorAlert("Mobile is required");
    die();
  }

  if (!is_numeric($mobile)) {
    header("Location: ../update-management.php?managId=".$manage_id);
      ErrorAlert("Please type only numbers.");
    die();
  }

  $countNumber = strlen($mobile);
    if ($countNumber != 10) {
    ErrorAlert("please enter 10 digit mobile no.");
    header("Location: ../update-management.php?managId=".$manage_id);
    die();
  }

  $sql = "UPDATE management SET name = '$name', desig = '$designation', mobile = '$mobile' WHERE manage_id = '$manage_id' ";
  $result = mysqli_query($conn, $sql);
  if ($result) {
    header("Location: ../management.php");
    SuccessAlert("Management updated sucessfully.");
  }

}



//add teachers//
if (isset($_POST['addTeacher']) && isset($_FILES['fileToUpload'])) {
  $name = mysqli_real_escape_string($conn, sanitize_input($_POST['name']));
  $subject = mysqli_real_escape_string($conn, sanitize_input($_POST['subject']));
  $fbLink = mysqli_real_escape_string($conn, sanitize_input($_POST['fbLink']));
  $twitterLink = mysqli_real_escape_string($conn, sanitize_input($_POST['twitterLink']));
  $about_teacher = mysqli_real_escape_string($conn, sanitize_input($_POST['about_teacher']));
  

  $file_name = mysqli_real_escape_string($conn, sanitize_input($_FILES['fileToUpload']['name']));
  $file_size = $_FILES['fileToUpload']['size'];
  $file_tmp = $_FILES['fileToUpload']['tmp_name'];
  $file_type = $_FILES['fileToUpload']['type'];
  $file_error = $_FILES['fileToUpload']['error'];

  if (!isset($name) || empty($name)) {
       // header("Location: ../add-photo.php");
       echo '<script>window.history.back();</script>';
       ErrorAlert("Name is required");
       die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
   echo '<script>window.history.back();</script>';
   ErrorAlert("Only letters and white space allowed.");
   die(); 
  }

  if (!isset($subject) || empty($subject)) {
     echo '<script>window.history.back();</script>';
     ErrorAlert("Subject is required.");
     die(); 
  }

  if (!empty($fbLink) || !isset($fbLink)) {
    if (filter_var($fbLink, FILTER_VALIDATE_URL) === FALSE) {
       echo '<script>window.history.back();</script>';
       ErrorAlert("Please enter a valid url");
       die(); 
    }
  }

  if (!empty($twitterLink) || !isset($twitterLink)) {
    if (filter_var($twitterLink, FILTER_VALIDATE_URL) === FALSE) {
       echo '<script>window.history.back();</script>';
       ErrorAlert("Please enter a valid url");
       die(); 
    }
  }

  if (!isset($about_teacher) || empty($about_teacher)) {
     echo '<script>window.history.back();</script>';
     ErrorAlert("Tell me some word about yourself.");
     die(); 
  }

  if (empty($file_name)) {
    echo '<script>window.history.back();</script>';
    ErrorAlert("Image is required");
    die();
  }

  $file_txt = explode(".", $file_name);
  $file_txt = end($file_txt);
  $file_txt = strtolower($file_txt);
  $extensions = ["jpg","jpeg","png"];

  if ($file_size > 2000000) {
       echo '<script>window.history.back();</script>';
      ErrorAlert("File size must be less than 2MB.");
      die();
    }

  if (in_array($file_txt, $extensions) == false) {
       // header("Location: ../add-photo.php");
       echo '<script>window.history.back();</script>';
       ErrorAlert("Please choose an jpg or png format");
       die();
  }


  $new_file = time()."-". basename($file_name);
  $terget = "../upload/teacher/".$new_file;
  move_uploaded_file($file_tmp, $terget);

  $sql = "INSERT INTO teachers(name, subject, fb_link, twitter_link, about_himself, img_url) 
          VALUES('$name', '$subject', '$fbLink' , '$twitterLink', '$about_teacher', '$new_file')";

  $result = mysqli_query($conn, $sql);
  if ($result) {
    header("Location: ../teacher.php");
    SuccessAlert("Teacher profile added sucessfully.");
  }else{
    ErrorAlert("something is wrong");
  }

}



//update teacher//
if (isset($_POST['updateTeacher'])) {
  $teacherId = mysqli_real_escape_string($conn, sanitize_input($_POST['teacherId']));
  $name = mysqli_real_escape_string($conn, sanitize_input($_POST['name']));
  $subject = mysqli_real_escape_string($conn,  sanitize_input($_POST['subject']));
  $fbLink = mysqli_real_escape_string($conn, sanitize_input($_POST['fbLink']));
  $twitterLink = mysqli_real_escape_string($conn, sanitize_input($_POST['twitterLink']));
  $about_teacher = mysqli_real_escape_string($conn, sanitize_input($_POST['about_teacher']));

  $file_name = mysqli_real_escape_string($conn, sanitize_input($_FILES['new_image']['name'])); 
  $file_type = $_FILES['new_image']['type'];
  $file_error = $_FILES['new_image']['error'];
  $file_size = $_FILES['new_image']['size'];
  $tmp_name = $_FILES['new_image']['tmp_name'];


  if (!isset($name) || empty($name)) {
     header("Location: ../update-teacher.php?techer_id=".$teacherId);
     ErrorAlert("Name is required");
     die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
     header("Location: ../update-teacher.php?techer_id=".$teacherId);
     ErrorAlert("Only letters and white space allowed.");
     die(); 
  }

  if (!isset($subject) || empty($subject)) {
     header("Location: ../update-teacher.php?techer_id=".$teacherId);
     ErrorAlert("Subject is required.");
     die(); 
  }

  if (!empty($fbLink) || !isset($fbLink)) {
    if (filter_var($fbLink, FILTER_VALIDATE_URL) === FALSE) {
       header("Location: ../update-teacher.php?techer_id=".$teacherId);
       ErrorAlert("Please enter a valid url");
       die(); 
    }
  }

  if (!empty($twitterLink) || !isset($twitterLink)) {
    if (filter_var($twitterLink, FILTER_VALIDATE_URL) === FALSE) {
       header("Location: ../update-teacher.php?techer_id=".$teacherId);
       ErrorAlert("Please enter a valid url");
       die(); 
    }
  }

  if (!isset($about_teacher) || empty($about_teacher)) {
     header("Location: ../update-teacher.php?techer_id=".$teacherId);
     ErrorAlert("Tell me few words about you.");
     die(); 
  }
  
  if (isset($tmp_name) && !empty($tmp_name)) {
    
    $allowedType = explode(".",$file_name);
    $allowedType = end($allowedType);
    $allowedType = strtolower($allowedType);
    $extensions = ["jpg", "jpeg", "png"];

    if (!in_array($allowedType, $extensions)) {
      header("Location: ../update-teacher.php?techer_id=".$teacherId);
      ErrorAlert("Please choose an jpg or png format");
      die();
    }
    if ($file_size > 1000000) {
      header("Location: ../update-teacher.php?techer_id=".$teacherId);
      ErrorAlert("File size must be less than 1MB.");
      die();
    }

    $sql3 = "SELECT techer_id, img_url FROM Teachers WHERE techer_id = '$teacherId'";
    $result3 = mysqli_query($conn, $sql3);
    $row3 = mysqli_fetch_assoc($result3);
    $old_image = $row3['img_url'];


    $new_file = time()."-". basename($file_name);
    $target = "../upload/teacher/".$new_file;
    move_uploaded_file($tmp_name, $target);
    unlink("../upload/teacher/".$old_image);
  }
       $sql = "UPDATE teachers SET name = '$name', subject = '$subject', fb_link = '$fbLink', twitter_link = '$twitterLink', about_himself = '$about_teacher' ";
       if (isset($tmp_name) && !empty($tmp_name)){
         $sql .= " , img_url = '$new_file' ";
       }
       $sql .= " WHERE techer_id = '$teacherId' ";
       // echo $sql;
       // exit();


      $result = mysqli_query($conn, $sql);
      if ($result) {
        header("Location: ../teacher.php");
        SuccessAlert("Teacher profile updated sucessfully.");
      }
  
}








//add course//
if (isset($_POST['add_course']) && isset($_FILES['course_img'])) {
  $course_name = mysqli_real_escape_string($conn, sanitize_input($_POST['course_name']));
  $admission_fees = mysqli_real_escape_string($conn, sanitize_input($_POST['admission_fees']));
  $duration = mysqli_real_escape_string($conn, sanitize_input($_POST['duration']));
  $total_fees = mysqli_real_escape_string($conn, sanitize_input($_POST['total_fees']));
  $description = mysqli_real_escape_string($conn, sanitize_input($_POST['description']));
  

  $course_img = mysqli_real_escape_string($conn, sanitize_input($_FILES['course_img']['name']));
  $file_size = $_FILES['course_img']['size'];
  $file_tmp = $_FILES['course_img']['tmp_name'];
  $file_type = $_FILES['course_img']['type'];
  $file_error = $_FILES['course_img']['error'];

  if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !=  $_SESSION['token']){
      header("Location: ../add-courses.php");
      ErrorAlert("csrf token missing or not match");
    }

  if (!isset($course_name) || empty($course_name)) {
       // header("Location: ../add-photo.php");
       echo '<script>window.history.back();</script>';
       ErrorAlert("Name is required");
       die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $course_name)) {
   echo '<script>window.history.back();</script>';
   ErrorAlert("Only letters and white space allowed.");
   die(); 
  }

  if (!isset($admission_fees) || empty($admission_fees)) {
     echo '<script>window.history.back();</script>';
     ErrorAlert("Admission fees is required.");
     die(); 
  }

  if(!is_numeric($admission_fees)){
    ErrorAlert("Please type only numbers.");
    echo '<script>window.history.back();</script>';
    die();  
  }

  if (!isset($duration) || empty($duration)) {
     echo '<script>window.history.back();</script>';
     ErrorAlert("Course duration is required.");
     die(); 
  }

  if(!is_numeric($duration)){
      ErrorAlert("Please type only numbers.");
      echo '<script>window.history.back();</script>';
      die();
  }

  if (!isset($total_fees) || empty($total_fees)) {
     echo '<script>window.history.back();</script>';
     ErrorAlert("Total fees is required.");
     die(); 
  }  

  if(!is_numeric($total_fees)){
      ErrorAlert("Please type only numbers.");
      echo '<script>window.history.back();</script>';
      die();
  }

  if (!isset($description) || empty($description)) {
     echo '<script>window.history.back();</script>';
     ErrorAlert("Tell me Few word about this course.");
     die(); 
  }

  if (empty($course_img)) {
    echo '<script>window.history.back();</script>';
    ErrorAlert("Image is required");
    die();
  }

  $file_txt = explode(".", $course_img);
  $file_txt = end($file_txt);
  $file_txt = strtolower($file_txt);
  $extensions = ["jpg","jpeg","png"];

  if ($file_size > 2000000) {
       echo '<script>window.history.back();</script>';
      ErrorAlert("File size must be less than 2MB.");
      die();
    }

  if (in_array($file_txt, $extensions) == false) {
       // header("Location: ../add-photo.php");
       echo '<script>window.history.back();</script>';
       ErrorAlert("Please choose an jpg or png format");
       die();
  }

  $new_file = time()."-". basename($course_img);
  $terget = "../upload/course/".$new_file;
  move_uploaded_file($file_tmp, $terget);

  $sql = "INSERT INTO courses(course_name, admission_fee, duration, total_fees, description, img_url) VALUES(?, ?, ?, ?, ?, ?)";
  
  $result = mysqli_prepare($conn, $sql);

  if ($result) {
    mysqli_stmt_bind_param($result, "ssiiss", $course_name, $admission_fees, $duration, $total_fees, $description, $new_file);


    mysqli_stmt_execute($result);
     header("Location: ../courses.php");
    SuccessAlert("Course added sucessfully.");

  }else{
    echo "Not inserted";
  }
  mysqli_stmt_close($result);

}





//update course//
if (isset($_POST['update_course']) && isset($_FILES['update_new_image'])) {
  $courseId = $_POST['course_id'];
  $course_name = mysqli_real_escape_string($conn, sanitize_input($_POST['course_name']));
  $admission_fees = mysqli_real_escape_string($conn, sanitize_input($_POST['admission_fees']));
  $duration = mysqli_real_escape_string($conn, sanitize_input($_POST['duration']));
  $total_fees = mysqli_real_escape_string($conn, sanitize_input($_POST['total_fees']));
  $description = mysqli_real_escape_string($conn, sanitize_input($_POST['description']));
  

  $course_img = mysqli_real_escape_string($conn, sanitize_input($_FILES['update_new_image']['name']));
  $file_size = $_FILES['update_new_image']['size'];
  $file_tmp = $_FILES['update_new_image']['tmp_name'];
  $file_type = $_FILES['update_new_image']['type'];
  $file_error = $_FILES['update_new_image']['error'];

  if (empty($_POST['csrf_token']) || $_POST['csrf_token'] !=  $_SESSION['token']){
      header("Location: ../update-courses.php");
      ErrorAlert("csrf token missing or not match");
    }

  if (!isset($course_name) || empty($course_name)){ 
     header("Location: ../update-courses.php?courseId=".$courseId);
     ErrorAlert("Name is required");
     die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $course_name)) {
   header("Location: ../update-courses.php?courseId=".$courseId);
   ErrorAlert("Only letters and white space allowed.");
   die(); 
  }

  if (!isset($admission_fees) || empty($admission_fees)) {
     header("Location: ../update-courses.php?courseId=".$courseId);
     ErrorAlert("Admission fees is required.");
     die(); 
  }

  if(!is_numeric($admission_fees)){
    header("Location: ../update-courses.php?courseId=".$courseId);
    ErrorAlert("Please type only numbers.");
    die();  
  }

  if (!isset($duration) || empty($duration)) {
     header("Location: ../update-courses.php?courseId=".$courseId);
     ErrorAlert("Course duration is required.");
     die(); 
  }

  if(!is_numeric($duration)){
      header("Location: ../update-courses.php?courseId=".$courseId);
      ErrorAlert("Please type only numbers.");
      die();
  }

  if (!isset($total_fees) || empty($total_fees)) {
     header("Location: ../update-courses.php?courseId=".$courseId);
     ErrorAlert("Total fees is required.");
     die(); 
  }  

  if(!is_numeric($total_fees)){
      header("Location: ../update-courses.php?courseId=".$courseId);
      ErrorAlert("Please type only numbers.");
      die();
  }

  if (!isset($description) || empty($description)) {
     header("Location: ../update-courses.php?courseId=".$courseId);
     ErrorAlert("Tell me Few word about this course.");
     die(); 
  }

  $sql3 = "SELECT course_id, img_url FROM courses WHERE course_id = '$courseId'";
  $result3 = mysqli_query($conn, $sql3);
  $row3 = mysqli_fetch_assoc($result3);
  $old_image = $row3['img_url'];

  if (isset($file_tmp) && !empty($file_tmp)) {

    $file_txt = explode(".", $course_img);
    $file_txt = end($file_txt);
    $file_txt = strtolower($file_txt);
    $extensions = ["jpg","jpeg","png"];

    if ($file_size > 2000000) {
      echheader("Location: ../update-courses.php?courseId=".$courseId);
      ErrorAlert("File size must be less than 2MB.");
      die();
    }

    if (in_array($file_txt, $extensions) == false) {
     header("Location: ../update-courses.php?courseId=".$courseId);
     ErrorAlert("Please choose an jpg or png format");
     die();
    }
  

    $new_file = time()."-". basename($course_img);
    $terget = "../upload/course/".$new_file;
    compressedImage($file_tmp, $terget, 60);
    unlink("../upload/course/".$old_image);
  }

  $sql = "UPDATE courses SET course_name = ?, admission_fee = ?, duration = ?, total_fees = ?,description = ?";
  $bindTypes = "siiis";
  $params = array($course_name, $admission_fees, $duration, $total_fees, $description);

  if (isset($file_tmp) && !empty($file_tmp)) {
      $sql .= ", img_url = ?";
      $bindTypes .= "s";
      $params[] = $new_file;
  }

  $sql .= " WHERE course_id = ?";
  
  $bindTypes .= "i";
  $params[] = $courseId;

  $result = mysqli_prepare($conn, $sql);
  if ($result) {
    mysqli_stmt_bind_param($result, $bindTypes, ...$params);
    mysqli_stmt_execute($result);
    header("Location: ../courses.php");
    SuccessAlert("Course updated sucessfully.");

  }else{
    echo "Not inserted";
  }

  
  mysqli_stmt_close($result);
}




















mysqli_close($conn);

?>