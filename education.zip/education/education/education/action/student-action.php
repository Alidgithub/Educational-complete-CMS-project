<?php
session_start();
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

include "../admin/action/config.php";

function sanitize_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}

function ErrorAlert($msg){
  $_SESSION['ErrorAlert'] = $msg;
}


// function compressedImage($source, $path, $quality) {

//   $info = getimagesize($source);

//   if ($info['mime'] == 'image/jpeg') 
//     $image = imagecreatefromjpeg($source);

//   elseif ($info['mime'] == 'image/gif') 
//     $image = imagecreatefromgif($source);

//   elseif ($info['mime'] == 'image/png') 
//    $image = imagecreatefrompng($source);

//   imagejpeg($image, $path, $quality);

// }




//ajax//
if(isset($_POST['getAdmisssionFees'])){
    $k = $_POST['id'];
    $k = trim($k);
    $sql = "SELECT course_id, admission_fee, duration  FROM courses WHERE course_id = '$k' ";
    // echo $sql;
    $result = mysqli_query($conn, $sql);
    $response = '';
    $duration = '';
    while ($row = mysqli_fetch_array($result)){
        $response .= '<option value='.$row['admission_fee'].'>'.$row['admission_fee'].'</option>';
        $duration .= '<option value='.$row['duration'].'>'.$row['duration'].' month</option>';
    }

    $data =  ["admission_fee" => $response, "duration" => $duration]; 
    echo json_encode($data);
}


//get otp with ajax//
if (isset($_POST['sendOtptoMobile'])) {
    $mobile = trim($_POST['mobile']);
    $otp = rand(1111,9999);

      if(preg_match("/^\d+\.?\d*$/",$mobile) && strlen($mobile)==10){

      $fields = array(
          "variables_values" => $otp,
          "route" => "otp",
          "numbers" => $mobile,
      );

      $curl = curl_init();

      curl_setopt_array($curl, array(
        CURLOPT_URL => "https://www.fast2sms.com/dev/bulkV2",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_SSL_VERIFYHOST => 0,
        CURLOPT_SSL_VERIFYPEER => 0,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => json_encode($fields),
        CURLOPT_HTTPHEADER => array(
          "authorization: NLeMPBYO45GiKfIpvt1VTnE9DZWFkAmURSlyswXb8h6qo70cQzg0ti8hfLszlHOqaep6R2BPbUTIcZ17 ",
          "accept: */*",
          "cache-control: no-cache",
          "content-type: application/json"
        ),
      ));

      $response = curl_exec($curl);
      $err = curl_error($curl);

      curl_close($curl);

      if ($err) {
        $response = ['status' => false, "message" => 'OTP Not sent!'];
      } else {
        $response = ["status" => true, "message" => 'OTP sent successfully'];
        $_SESSION['St_Otp'] = $otp;
       
      }

      echo json_encode($response);

      }

    }







//add user//
if (isset($_POST['stInfo'])) {

  $application_id = "WBSE".rand(1000, 9999);
  $password = strtok($_POST['stName'], " ").rand(1000, 9999);

  $application_id = mysqli_real_escape_string($conn, sanitize_input($application_id));
  $password = mysqli_real_escape_string($conn, sanitize_input($password));

  $stName = mysqli_real_escape_string($conn, sanitize_input($_POST['stName']));
  $fName = mysqli_real_escape_string($conn, sanitize_input($_POST['fName']));
  $course_id = mysqli_real_escape_string($conn, sanitize_input($_POST['course']));
  $birthDate = mysqli_real_escape_string($conn, sanitize_input($_POST['birth']));
  $birthDate = date('Y-m-d', strtotime($birthDate));
  $religion = mysqli_real_escape_string($conn, sanitize_input($_POST['religion']));
  $email = mysqli_real_escape_string($conn, sanitize_input($_POST['email']));
  $aadhaar = mysqli_real_escape_string($conn, sanitize_input($_POST['aadhaar']));
  $caste = mysqli_real_escape_string($conn, sanitize_input($_POST['caste']));
  $qualification = mysqli_real_escape_string($conn, sanitize_input($_POST['qualification']));
  $marks = mysqli_real_escape_string($conn, sanitize_input($_POST['marks']));
  $gender = mysqli_real_escape_string($conn, $_POST['gender']);
  $SendOtp = $_POST['otp'];
  $captcha = mysqli_real_escape_string($conn, $_POST['captcha']);
  $mobile = mysqli_real_escape_string($conn, sanitize_input($_POST['mobile']));
  $address = mysqli_real_escape_string($conn, sanitize_input($_POST['address']));
 
  $file_name = mysqli_real_escape_string($conn, sanitize_input($_FILES['stPhoto']['name'])); 
  $file_type = $_FILES['stPhoto']['type'];
  $file_error = $_FILES['stPhoto']['error'];
  $file_size = $_FILES['stPhoto']['size'];
  $tmp_name = $_FILES['stPhoto']['tmp_name'];

 if (!isset($course_id) || empty($course_id)) {
    ErrorAlert("Course is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

 if (!isset($stName) || empty($stName)) {
    ErrorAlert("Name is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $stName)) {
    ErrorAlert("Only letters and white space allowed. ($stName)");
    echo '<script>window.history.back();</script>';
    die();
  }

  if (!isset($fName) || empty($fName)) {
    ErrorAlert("Father name is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if (!preg_match("/^[a-zA-Z-' ]*$/", $fName)) {
    ErrorAlert("Only letters and white space allowed. ($fName)");
    echo '<script>window.history.back();</script>';
    die();
  }

  if (!isset($birthDate) || empty($birthDate)) {
    ErrorAlert("Date of birth is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if (!isset($religion) || !preg_match("/^[a-zA-Z-' ]*$/", $religion)) {
    ErrorAlert("Only letters and white space allowed. ($religion)");
    echo '<script>window.history.back();</script>';
    die();
  }

  if(!isset($email) || empty($email)){
    ErrorAlert("Email is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    ErrorAlert("$email is not a valid email address");
    echo '<script>window.history.back();</script>';
    die(); 
  }

  if(!isset($aadhaar) || empty($aadhaar)){
    ErrorAlert("Aadhaar number is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if (strlen($aadhaar) != 12) {
    ErrorAlert("Enter 12 digit only. Aadhaar no.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if(!isset($qualification) || empty($qualification)){
    ErrorAlert("Qualification is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if(!isset($marks) || empty($marks)){
    ErrorAlert("Marks is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if(!isset($address) || empty($address)){
    ErrorAlert("Address is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if (isset($tmp_name) && !empty($tmp_name)) {
    
    $file_txt = explode(".", $file_name);
    $file_txt = end($file_txt);
    $file_txt = strtolower($file_txt);
    $extensions = ["jpg","jpeg","png"];

    if ($file_size > 2000000) {
      echo '<script>window.history.back();</script>';
      ErrorAlert("File size must be less than 2MB.");
      die();
    }

    if (in_array($file_txt, $extensions) == false) {
      echo '<script>window.history.back();</script>';
      ErrorAlert("Please choose an jpg or png format");
      die();
    }

    $new_file = time()."-". basename($file_name);
    $terget = "../admin/upload/studentImage/".$new_file;
    move_uploaded_file($tmp_name, $terget);

  }else{
    ErrorAlert("image is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if(!isset($captcha) || empty($captcha)){
    ErrorAlert("Please enter Captcha.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if ($captcha != $_SESSION["captcha"]) {
    ErrorAlert("You entered wrong captcha.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if(!isset($mobile) || empty($mobile)){
    ErrorAlert("Mobile number is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  function validate_mobile($num){
      return preg_match('/^[6-9]\d{9}$/', $num);
  }

  if(!validate_mobile($mobile)){
    ErrorAlert("Enter 10 digit Mobile number.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if(!isset($SendOtp) || empty($SendOtp)){
    ErrorAlert("OTP is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if ($_SESSION['St_Otp'] != $SendOtp) {
    ErrorAlert("Wrong OTP enterd");
    echo '<script>window.history.back();</script>';
    die();
  }

  $sql1 = "SELECT mobile FROM student_info WHERE application_id = '$application_id'";
  $result1 = mysqli_query($conn, $sql1) or die("Query Failed");
  if (mysqli_num_rows($result1) > 0 ) {
    ErrorAlert("Email Id already exists try another email.");
    echo '<script>window.history.back();</script>';
    die();
  }else{
    $md5_pass = md5($password);
    $sql = "INSERT INTO student_info(application_id, password, course_id, st_name, f_name ,date_of_birth, religion, email, aadhaar, caste, qualification, marks, gender, mobile, address, img_url) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    $result = mysqli_prepare($conn, $sql);
    if ($result) {
      mysqli_stmt_bind_param($result, "ssisssssissisiss", $application_id, $md5_pass, $course_id, $stName, $fName, $birthDate, $religion, $email, $aadhaar, $caste, $qualification, $marks, $gender, $mobile, $address, $new_file);
      mysqli_stmt_execute($result);
     

      //send email//
    require 'PHPMailer/src/Exception.php';
    require 'PHPMailer/src/PHPMailer.php';
    require 'PHPMailer/src/SMTP.php';


      $mail = new PHPMailer(true);

  try {
      //Server settings
      // $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
      $mail->isSMTP();                                            //Send using SMTP
      $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
      $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
      $mail->Username   = 'alidsk4@gmail.com';                     //SMTP username
      $mail->Password   = 'hroqnnsmvyqhdble';                               //SMTP password
      $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
      $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

      //Recipients
      $mail->setFrom('alidsk4@gmail.com', 'Send by Alid Shaikh');
      $mail->addAddress($email, 'Dear Student');     //Add a recipient
      $mail->addReplyTo('alidsk4@gmail.com',);
      // $mail->addCC('alidshaikh936@gmail.com');
      // $mail->addBCC('bcc@example.com');

      //Content
      $mail->isHTML(true);                                  //Set email format to HTML
      $mail->Subject = 'Your Application Id Password';
      $mail->Body    = 'Application Id = '.$application_id. ' and Password = '.$password;
      // $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

      $mail->send();
      header("Location: ../student-login.php?smg=application Id and Password has been send in your email");
  } catch (Exception $e) {
      echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
  }
      unset($_SESSION['St_Otp']);
      unset($_SESSION['captcha']);
    }

  }
  
}


//student login//

if (isset($_POST['st_login'])) {
  $application_id = mysqli_real_escape_string($conn, sanitize_input($_POST['application']));
  $password = mysqli_real_escape_string($conn, sanitize_input($_POST['password']));

  if (!isset($application_id) || empty($application_id)) {
    ErrorAlert("Course is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

  if (!isset($password) || empty($password)) {
    ErrorAlert("Password is required.");
    echo '<script>window.history.back();</script>';
    die();
  }

$password = md5($password);
$sql2 = "SELECT id, application_id, password FROM student_info WHERE application_id = '$application_id' AND password = '$password'";
$result2 = mysqli_query($conn, $sql2);
if (mysqli_num_rows($result2) > 0 ) {
  $row = mysqli_fetch_assoc($result2);
  $_SESSION['st_id'] = $row['id'];
  $_SESSION['application_id'] = $row['application_id'];

  header("Location: ../Student-profile/index.php");
}else{
  ErrorAlert("Please check Application Id or Password");
  echo '<script>window.history.back();</script>';
  die();
}



}







?>