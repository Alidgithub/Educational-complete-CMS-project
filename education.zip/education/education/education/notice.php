<?php
include("admin/action/config.php");
$sql = "SELECT * FROM notice ORDER BY id DESC";
$result = mysqli_query($conn, $sql);
?>
<br><br><br><br><br>

	<?php if (mysqli_num_rows($result) > 0 ) : ?>
	<div class="col-md-6 animate-box">
		<span>About Our College</span>
		<h2>Welcome to Kuli Chowrasta College of Education</h2>
		<p>Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat cauctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per Mauris in erat justo.</p>
		<p>Nullam ac urna eu felis dapibus condimentum sit amet a augue. Sed non neque elit. Sed ut imperdiet nisi. Proin condimentum fermentum nunc. Etiam pharetra, erat sed.</p>
		<p>Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat cauctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per Mauris in erat justo.</p>
		<p>Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat cauctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per Mauris in erat justo.</p>
		<p>Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat cauctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per Mauris in erat justo.</p>
	</div>
	<div class="col-md-6 animate-box" style="background-color: #ff8080; border-radius: 30px;">
		<h2 style="text-align: center; color: #0000ff;"><u>NOTICEBOARD</u></h2>
		<?php
			while($row = mysqli_fetch_assoc($result)):
		
		?>
		<div class="fh5co-event animate-box">
			<div class="date text-center text-primary"><span><?php echo date("d",strtotime($row['noticeDate'])); ?><br><?php echo date("M",strtotime($row['noticeDate'])); ?>.</span></div>
			<h3 style="font-size: 25px;"><a href="#"><?php echo $row['tittle']; ?></a></h3>
			<p style="font-size: 18px; color: black	;"><?php echo $row['description']; ?></p>
		</div>
		<?php endwhile ?>
		
	</div>
	<?php endif ?>