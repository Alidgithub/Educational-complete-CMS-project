<?php
// session_start();
// if (isset($_SESSION['username'])) {
//     header("location: admin/users.php");
// }
?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Education &mdash; Free Website Template, Free HTML5 Template by freehtml5.co</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
		<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
		<meta name="author" content="freehtml5.co" />
		<meta property="og:title" content=""/>
		<meta property="og:image" content=""/>
		<meta property="og:url" content=""/>
		<meta property="og:site_name" content=""/>
		<meta property="og:description" content=""/>
		<meta name="twitter:title" content="" />
		<meta name="twitter:image" content="" />
		<meta name="twitter:url" content="" />
		<meta name="twitter:card" content="" />
		
		<!-- Animate.css -->
		<link rel="stylesheet" href="css/animate.css">
		<!-- Icomoon Icon Fonts-->
		<link rel="stylesheet" href="css/icomoon.css">
		<!-- Magnific Popup -->
		<link rel="stylesheet" href="css/magnific-popup.css">
		<!-- Owl Carousel  -->
		<link rel="stylesheet" href="css/owl.carousel.min.css">
		<link rel="stylesheet" href="css/owl.theme.default.min.css">
		<!-- Flexslider  -->
		<link rel="stylesheet" href="css/flexslider.css">
		<!-- Pricing -->
		<link rel="stylesheet" href="css/pricing.css">
		<!-- Theme style  -->
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/bootstrap.css">
		<!-- Modernizr JS -->
		<script src="js/modernizr-2.6.2.min.js"></script>
		<!-- FOR IE9 below -->
	</head>
	<body>
		<div class="container">
			<?php
			include("include/header.php");
			?>
			<?php
			include("admin/action/config.php");
			$sql2 = "SELECT * FROM slider ORDER BY slider_id DESC";
			$result2 = mysqli_query($conn, $sql2);
			if (mysqli_num_rows($result2)) :
			?>
			<aside id="fh5co-hero">
				<div class="flexslider animate-box">
					<ul class="slides">
						<?php while ($row2 = mysqli_fetch_assoc($result2)) : ?>
						<li style="background-image: url('admin/upload/<?php echo $row2['img_url']; ?>');">
							<div class="overlay-gradient"></div>
							<div class="row">
								<div class="col-md-8 col-md-offset-2 text-center slider-text">
									<div class="slider-text-inner">
										<h1><?php echo $row2['tittle']; ?></h1>
										<h2><?php echo $row2['sub_tittle']; ?></h2>
										<p><a class="btn btn-primary btn-lg" href="apply_form.php">Apply for batter Future !</a></p>
									</div>
								</div>
							</div>
						</li>
						<?php endwhile ?>
					</ul>
				</div>
			</aside>
			<?php endif ?>
			
			<!-- Notice Board open -->
			<?php include"notice.php"; ?>
			<!-- Notice Board close -->
			<!--////////// Course open ////////// -->
			<?php
			$sql6 = "SELECT * FROM courses ORDER BY course_id DESC LIMIT 2";
				$result6 = mysqli_query($conn, $sql6);
				if (mysqli_num_rows($result6)) :
			?>
			<div id="fh5co-course">
				<div class="row animate-box">
					<div class="col-md-6 col-md-offset-3 text-center fh5co-heading">
						<h2>Our Course</h2>
						<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
					</div>
				</div>
				<div class="row">
					<?php while ($row6 = mysqli_fetch_assoc($result6)) : ?>
					<div class="col-md-6 animate-box">
						<div class="course">
							<a href="#" class="course-img" style="background-image: url('admin/upload/course/<?php echo $row6['img_url']; ?>');">
							</a>
							<div class="desc">
								<h3 style="margin-top: 0px"><a href="#"><?php echo $row6['course_name']; ?></a></h3>
								<ul>
									<li>Admission fee <b><?php echo $row6['admission_fee']; ?></b> /- Rupees only</li>
									<li>Total course fee <b><?php echo $row6['total_fees']; ?></b> /- Rupees only</li>
									<li>Course duration <b><?php echo $row6['duration']; ?></b> months </li>
								</ul>
								<h4>Description:</h4>
								<p><?php echo $row6['description']; ?></p>
								<span><a href="#" class="btn btn-primary btn-sm btn-course">Aplly Now</a></span>
								<span><a href="courses.php" class="btn btn-primary btn-sm btn-course">More...</a></span>
							</div>
						</div>
					</div>
					<?php endwhile ?>
				</div>
			</div>
			<?php endif ?>
			<!--////////// Course Course close ////////// -->
			<!--////////// teacher open ////////// -->
			<?php include "teachers.php" ?>
			<!--////////// teacher open ////////// -->
			<!--////////// Events open ////////// -->
			<div id="fh5co-blog">
				<div class="row animate-box">
					<div class="col-md-8 col-md-offset-2 text-center fh5co-heading">
						<h2>Social Events</h2>
						<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
					</div>
				</div>
				<div class="row row-padded-mb">
					<div class="col-md-4 animate-box">
						<div class="fh5co-event" style="background-color: #cce6ff;">
							<div class="date text-center text-primary"><span>15<br>Mar.</span></div>
							<h3><a href="#">USA, International Triathlon Event</a></h3>
							<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. word mountains, far from the countries Vokalia and Consonantia, there live the blind texts</p>
							<!-- <p><a href="#">Read More</a></p> -->
						</div>
					</div>
					<div class="col-md-4 animate-box" >
						<div class="fh5co-event" style="background-color: #cce6ff;">
							<div class="date text-center text-primary"><span>15<br>Mar.</span></div>
							<h3><a href="#">USA, International Triathlon Event</a></h3>
							<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
							<!-- <p><a href="#">Read More</a></p> -->
						</div>
					</div>
					<div class="col-md-4 animate-box">
						<div class="fh5co-event" style="background-color: #cce6ff;">
							<div class="date text-center text-primary"><span>15<br>Mar.</span></div>
							<h3><a href="#">New Device Develope by Microsoft</a></h3>
							<p>Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts.</p>
							<!-- <p><a href="#">Read More</a></p> -->
						</div>
					</div>
				</div>
				<!--////////// Cour Events close ////////// -->
				
				<!-- ////////// gallery open ////////// -->
				<div id="fh5co-staff">
					<div class="row">
						<div class="col-md-8 col-md-offset-2 text-center fh5co-heading animate-box">
							<h2>College Photos</h2>
							<p>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.</p>
						</div>
						<?php
						$sql3 = "SELECT * FROM gallery WHERE photo_cat_id = 2 ORDER BY photo_id DESC";
						$result3 = mysqli_query($conn, $sql3);
						if (mysqli_num_rows($result) > 0 ) :
						while($row = mysqli_fetch_assoc($result3)):
						?>
						<div class="col-md-3 text-center animate-box">
							<div class="staff">
								<div class="staff-img" style="background-image: url('admin/upload/<?php echo $row['image_url']; ?>');">
									<ul class="fh5co-social">
										<li><a target="_blank" href="admin/upload/<?php echo $row['image_url']; ?>"><i class="icon-eye3"></i></a></li>
										<li><a href="download.php?fileName=<?php echo $row['image_url']; ?>"><i class="icon-download4"></i></a></li>
									</ul>
								</div>
							</div>
						</div>
						<?php endwhile ?>
						<?php endif ?>
					</div>
				</div>
				<!-- ////////// gallery close ////////// -->
				<!--////////// Counter open ////////// -->
				<div id="fh5co-counter" class="fh5co-counters" style="background-image: url(images/img_bg_4.jpg);" data-stellar-background-ratio="0.5">
					<div class="overlay"></div>
					<div class="row">
						<div class="col-md-10 col-md-offset-1">
							<div class="row">
								<div class="col-md-3 col-sm-6 text-center animate-box">
									<span class="icon"><i class="icon-world"></i></span>
									<span class="fh5co-counter js-counter" data-from="0" data-to="3297" data-speed="5000" data-refresh-interval="50"></span>
									<span class="fh5co-counter-label">Foreign Followers</span>
								</div>
								<div class="col-md-3 col-sm-6 text-center animate-box">
									<span class="icon"><i class="icon-study"></i></span>
									<span class="fh5co-counter js-counter" data-from="0" data-to="3700" data-speed="5000" data-refresh-interval="50"></span>
									<span class="fh5co-counter-label">Students Enrolled</span>
								</div>
								<div class="col-md-3 col-sm-6 text-center animate-box">
									<span class="icon"><i class="icon-bulb"></i></span>
									<span class="fh5co-counter js-counter" data-from="0" data-to="5034" data-speed="5000" data-refresh-interval="50"></span>
									<span class="fh5co-counter-label">Classes Complete</span>
								</div>
								<div class="col-md-3 col-sm-6 text-center animate-box">
									<span class="icon"><i class="icon-head"></i></span>
									<span class="fh5co-counter js-counter" data-from="0" data-to="1080" data-speed="5000" data-refresh-interval="50"></span>
									<span class="fh5co-counter-label">Certified Teachers</span>
								</div>
							</div>
						</div>
					</div>
				</div>
				<br><br><br><br>
				<!--//////////  Counter close ////////// -->
				<?php include("include/footer.php") ?>
				<!-- </div> -->
			</div>
			<!-- </div> -->
			<div class="gototop js-top">
				<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
			</div>
			
			<!-- jQuery -->
			<script src="js/jquery.min.js"></script>
			<!-- jQuery Easing -->
			<script src="js/jquery.easing.1.3.js"></script>
			<!-- Bootstrap -->
			<script src="js/bootstrap.min.js"></script>
			<!-- Waypoints -->
			<script src="js/jquery.waypoints.min.js"></script>
			<!-- Stellar Parallax -->
			<script src="js/jquery.stellar.min.js"></script>
			<!-- Carousel -->
			<script src="js/owl.carousel.min.js"></script>
			<!-- Flexslider -->
			<script src="js/jquery.flexslider-min.js"></script>
			<!-- countTo -->
			<script src="js/jquery.countTo.js"></script>
			<!-- Magnific Popup -->
			<script src="js/jquery.magnific-popup.min.js"></script>
			<script src="js/magnific-popup-options.js"></script>
			<!-- Google Map -->
			<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>
			<script src="js/google_map.js"></script>
			<!-- Count Down -->
			<script src="js/simplyCountdown.js"></script>
			<!-- Main -->
			<script src="js/main.js"></script>
			<script>
			var d = new Date(new Date().getTime() + 1000 * 120 * 120 * 2000);
			// default example
			simplyCountdown('.simply-countdown-one', {
			year: d.getFullYear(),
			month: d.getMonth() + 1,
			day: d.getDate()
			});
			//jQuery example
			$('#simply-countdown-losange').simplyCountdown({
			year: d.getFullYear(),
			month: d.getMonth() + 1,
			day: d.getDate(),
			enableUtc: false
			});
			</script>
		</div>
	</body>
</html>