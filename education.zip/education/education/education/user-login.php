<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>log in</title>
		<style type="text/css">
			.main_div1{
				background-color: white;
				margin: auto;
				height: 250px;
				width: 650px;
				margin-top: 100px;
			box-shadow: 0 .4rem 1rem;
				
			}
			.main_div2{
				height: 250px;
				width: 31.3%;
				float: left;
				margin-top: 0px;
			}
			.main_div3{
				height: 250px;
				width: 68%;
				float: right;
			}
			h1{
				text-align: center;
				color: #0072c5;
				font-size: 28px;
			font-weight: bold;
			}
			input{
				
				height: 35px;
				background-color: #edf2f6;
				box-shadow: 10px darkred;
				width: 315px;
				border:  none;
			}
			input:focus{
				border: 3px solid blue;
			}
			input,p{
				margin-left: 75px;
			}
			p{
				font-weight: bold;
			}
			button{
				background-color: blue;
				border: none;
				height: 42px;
				cursor: pointer;
				color: white;
				font-size: 15px;
				width: 325px;
				margin-right: -30px;
				margin-top: 25px;
				
			}
			img{
				margin-top: 30px;
				height: 200px;
			}
			
			
		</style>
	</head>
	<body style="background-color:#edf2f6;">
		<form action="admin_log_in.php" method="post">
			<div class="main_div1">
				<div class="main_div2">
					<img src="images/book.png" alt="book image (logo)">
					
				</div>
				<div class="main_div3">
					<h1>Log In</h1>
					<p>MOBILE NO.</p>
					<input type="text" name="mobile" placeholder="Mobile" required>
					<br>
					
					<center> <button type="submit" name="user_login">Send OTP</button> </center>
					<p>Are you already registered? <a href="user-signup.php">Sign Up here</a></p>
				</div>
				
			</div>
		</form>
	</body>
</html>