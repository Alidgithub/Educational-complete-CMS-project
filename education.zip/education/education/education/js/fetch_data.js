function one(){
	// var x = document.getElementById("courses").value;
	var x = $("#courses").val();
	$.ajax({
		url: "action/student-action.php",
		method: "POST",
		data:{
			getAdmisssionFees: '',
			id :x
		},
		success:function(data) {
			var json = JSON.parse(data);
			$("#admissionFees").html(json.admission_fee);
			$("#duration").html(json.duration);
		}
	})
}

function sendOTP(){
	// var x = document.getElementById("courses").value;
	var mobile = $("#mobile").val();
	if(mobile == ''){
		alert('Please enter mobile!');
		return false;
	}
	$.ajax({
		url: "action/student-action.php",
		method: "POST",
		data:{
			sendOtptoMobile : '',
			mobile : mobile
		},
		success:function(data) {
			var json = JSON.parse(data);
			alert(json.message);
			if(json.status){
				$("#sendOtp").attr("disabled", 'disabled');
			}

			
		}
	})
}


$('#reload').click(function(){
        var timestamp = new Date().getTime();
        $('#captcha').attr('src','Captcha/Captcha.php?'+timestamp)
    })