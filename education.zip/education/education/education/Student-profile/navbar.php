  <nav>
    <ul>
      <li><a href="#" class="logo">
        <img src="./pic/logo.jpg">
        <span class="nav-item">Your Name</span>
      </a></li>
      <li><a href="index.php">
        <i class="fas fa-user"></i>
        <span class="nav-item">Profile</span>
      </a></li>
      <li><a href="#">
        <i class="fas fa-certificate"></i>
        <span class="nav-item">Certificate</span>
      </a></li>
      <li><a href="Payment.php">
        <i class="fas fa-indian-rupee-sign"></i>
        <span class="nav-item">Payment</span>
      </a></li>
      <li><a href="#">
        <i class="fas fa-id-card"></i>
        <span class="nav-item">Genetate Id Card</span>
      </a></li>
      <li><a href="#">
        <i class="fas fa-cog"></i>
        <span class="nav-item">Setting</span>
      </a></li>
      <li><a href="#" class="logout">
        <i class="fas fa-sign-out-alt"></i>
        <span class="nav-item">Log out</span>
      </a></li>
    </ul>
  </nav>