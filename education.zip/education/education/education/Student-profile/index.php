<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Student Profile</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

</head>
<body>
  <div class="container">
    <?php include "navbar.php" ?>


    <section class="main">
      <div class="main-top">
        <h1>Your Profile</h1>
      </div>

      <div class="users">
        <div class="card">
          <img src="./pic/img4.jpg">
          <h4>Salina micheal</h4>
          <p>Diploma in computer</p>
          <div class="per">
            <table>
              <tr>
                <td><span>12</span></td>
                <td><span>25%</span></td>
              </tr>
              <tr>
                <td>Month</td>
                <td>Complite</td>
              </tr>
            </table>
          </div>
         <center> <a href="#"><button>Click to view Profile</button></a></center>
        </div>
      </div>

      <div class="users">
        <div class="card">
        
          <table>
            <tbody class="table">
                <tr>
                    <td><b>Name :-</b></td>
                    <td>Alid Shaikh</td>
                    <td><b>Father's Name :-</b></td>
                    <td>Alid Shaikh</td>
                </tr>
                <tr>
                    <td><b>Mother's Name :-</b></td>
                    <td>Rafikul Islam</td>
                    <td><b>Date of Birth :-</b></td>
                    <td>Rafikul Islam</td>
                </tr>
                <tr>
                    <td><b>Blood Group :-</b></td>
                    <td>O+</td>
                    <td><b>Nationality :-</b></td>
                    <td>Indian</td>
                </tr>
                <tr>
                    <td><b>Session :-</b></td>
                    <td>2018-2020</td>
                    <td><b>Religion :-</b></td>
                    <td>Islam</td>
                </tr>
                <tr>
                    <td><b>Email :-</b></td>
                    <td>Alidsk4@gmail.com</td>
                    <td><b>Mobile No :-</b></td>
                    <td>8089674601</td>
                </tr>
                <tr>
                    <td><b>Guardian's Number :-</b></td>
                    <td>9734842267</td>
                    <td><b>Aadhaar No. :-</b></td>
                    <td>334927327886</td>
                </tr>
                <tr>
                    <td><b>Subject applied for (B.Ed only) :-</b></td>
                    <td>Alid Shaikh</td>
                    <td><b>Caste :-</b></td>
                    <td>General</td>
                </tr>
                <tr>
                    <td><b>Last University/Board Pass :-</b></td>
                    <td>Rafikul Islam</td>
                    <td><b>Last University Regn No (Only for BEd student) :-</b></td>
                    <td>General</td>
                </tr>
                <tr>
                    <td><b>Gender :-</b></td>
                    <td>Male</td>
                    <td><b>Class :-</b></td>
                    <td>D.ed</td>
                </tr>
                <tr>
                    <td><b>Address with pin code :-</b></td>
                    <td>VILL-KULI CHOWRASTA, P.O-KULI KANDI,
                     P.S-BURWAN, DIST- MURSHIDABAD,
                      PIN-742168</td>
                    <td><b>Whether Fresher or Deputed :-</b></td>
                    <td>Fresher</td>
                </tr>
            </tbody>
        </table>
      </div>
        
      </div>

    </section>
  </div>



</body>
</html>
