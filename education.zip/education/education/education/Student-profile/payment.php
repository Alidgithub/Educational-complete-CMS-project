<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Student Payment</title>
  <link rel="stylesheet" href="style.css" />
  <!-- Font Awesome Cdn Link -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

</head>
<body>
  <div class="container">

    <?php include "navbar.php" ?>

    <section class="main">
      <div class="main-top">
        <h1>Payment</h1>
      </div>

      <div class="users">
        <div class="card">
          <img src="./pic/img4.jpg">
          <h4>Salina micheal</h4>
          <p>Diploma in computer</p>
          <div class="per">
            <table>
              <tr>
                <td><span>Course Amount</span></td>
                <td><span>Pay Amount</span></td>
                <td><span>Panding Amount</span></td>
              </tr>
              <tr>
                <td><i class="fas fa-indian-rupee-sign"></i>4500</td>
                <td> <i class="fas fa-indian-rupee-sign"></i> 3000</td>
                <td> <i class="fas fa-indian-rupee-sign"></i> 1500</td>
              </tr>
            </table>
          </div>
          <center>
          <a href="check-out-form.php"><button>Click to Pay</button></a>
        </center>
        </div>
      </div>


      <section class="attendance">
        <div class="attendance-list">
          <h1>Transaction Details</h1>
          <table class="table">
            <thead>
              <tr>
                <th>SL No.</th>
                <th>Date</th>
                <th>Status</th>
                <th>Transaction Date</th>
                <th>Amount</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>20/20/2023</td>
                <td>Success</td>
                <td>20/20/2023</td>
                <td> <i class="fas fa-indian-rupee-sign"></i>1000</td>
              </tr>
              <tr>
                <td>2</td>
                <td>20/20/2023</td>
                <td>Success</td>
                <td>20/20/2023</td>
                <td> <i class="fas fa-indian-rupee-sign"></i>500</td>
              </tr>
               <tr>
                <td>2</td>
                <td>20/20/2023</td>
                <td>Panding</td>
                <td>20/20/2023</td>
                <td> <i class="fas fa-indian-rupee-sign"></i>2000</td>
              </tr>
               <tr>
                <td>2</td>
                <td>20/20/2023</td>
                <td>Panding</td>
                <td>20/20/2023</td>
                <td> <i class="fas fa-indian-rupee-sign"></i>300</td>
              </tr>
               <tr>
                <td>2</td>
                <td>20/20/2023</td>
                <td>Panding</td>
                <td>20/20/2023</td>
                <td> <i class="fas fa-indian-rupee-sign"></i>700</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </section>
  </div>



</body>
</html>
