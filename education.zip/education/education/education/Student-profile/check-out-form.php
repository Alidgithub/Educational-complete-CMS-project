<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>cheeck out</title>
		<link rel="stylesheet" type="text/css" href="bootstrap.min.css">
	</head>
	<body>
		<form class="form my-4" method="POST" action="pay.php">
			<div class="container my-4 p-4 shadow w-50">
				<h2 class="text-center"style="color: blue;">Payment</h2>
				<label for="name">About Transaction</label>
				<input class="form-control mb-2" type="text" name="name">
				<label for="">Which Date / Mounth</label>
				<input class="form-control mb-2" type="date" name="date">
				<label for="">Amount</label>
				<input class="form-control mb-2" type="number" name="amount">
				<input class="form-control mb-2 bg-primary text-light" type="submit" name="submit" value="Pay">
			</div>
		</form>
	</body>
</html>