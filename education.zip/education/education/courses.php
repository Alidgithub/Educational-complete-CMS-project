<?php include "admin/action/config.php" ?>
<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Education &mdash; Free Website Template, Free HTML5 Template by freehtml5.co</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
		<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
		<meta name="author" content="freehtml5.co" />
		<meta property="og:title" content=""/>
		<meta property="og:image" content=""/>
		<meta property="og:url" content=""/>
		<meta property="og:site_name" content=""/>
		<meta property="og:description" content=""/>
		<meta name="twitter:title" content="" />
		<meta name="twitter:image" content="" />
		<meta name="twitter:url" content="" />
		<meta name="twitter:card" content="" />
		
		<!-- Animate.css -->
		<link rel="stylesheet" href="css/animate.css">
		<!-- Icomoon Icon Fonts-->
		<link rel="stylesheet" href="css/icomoon.css">
		<!-- Magnific Popup -->
		<link rel="stylesheet" href="css/magnific-popup.css">
		<!-- Owl Carousel  -->
		<link rel="stylesheet" href="css/owl.carousel.min.css">
		<link rel="stylesheet" href="css/owl.theme.default.min.css">
		<!-- Flexslider  -->
		<link rel="stylesheet" href="css/flexslider.css">
		<!-- Pricing -->
		<link rel="stylesheet" href="css/pricing.css">
		<!-- Theme style  -->
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/bootstrap.css">
		<!-- Modernizr JS -->
		<script src="js/modernizr-2.6.2.min.js"></script>
	</head>
	<body>
		
		<div class="fh5co-loader"></div>
		
		<div id="page">
			<?php include("include/header.php") ?>
			
			<aside id="fh5co-hero">
				<div class="flexslider">
					<ul class="slides">
						<li style="background-image: url(images/img_bg_4.jpg);">
							<div class="overlay-gradient"></div>
							<div class="row">
								<div class="col-md-8 col-md-offset-2 text-center slider-text">
									<div class="slider-text-inner">
										<h1 class="heading-section">Our Courses</h1>
										<h2>Dignissimos asperiores vitae velit veniam totam fuga molestias accusamus alias autem provident. Odit ab aliquam dolor eius.
										<br>
										<a href="index.php">HOME</a>
										</h2>
									</div>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</aside>
			
						<?php
			$sql6 = "SELECT * FROM courses ORDER BY course_id DESC";
				$result6 = mysqli_query($conn, $sql6);
				if (mysqli_num_rows($result6)) :
			?>
			<div id="fh5co-course">
				<div class="row">
					<?php while ($row6 = mysqli_fetch_assoc($result6)) : ?>
					<div class="col-md-6 animate-box">
						<div class="course">
							<a href="#" class="course-img" style="background-image: url('admin/upload/course/<?php echo $row6['img_url']; ?>');">
							</a>
							<div class="desc">
								<h3 style="margin-top: 0px"><a href="#"><?php echo $row6['course_name']; ?></a></h3>
								<ul>
									<li>Admission fee <b><?php echo $row6['admission_fee']; ?></b> /- Rupees only</li>
									<li>Total course fee <b><?php echo $row6['total_fees']; ?></b> /- Rupees only</li>
									<li>Course duration <b><?php echo $row6['duration']; ?></b> months </li>
								</ul>
								<h4>Description:</h4>
								<p><?php echo $row6['description']; ?></p>
								<span><a href="#" class="btn btn-primary btn-sm btn-course">Aplly Now</a></span>
								<span><a href="#" class="btn btn-primary btn-sm btn-course">Details</a></span>
							</div>
						</div>
					</div>
					<?php endwhile ?>
				</div>
			</div>
			<?php endif ?>
			<?php
			include("include/footer.php");
			?>
		</div>
		<div class="gototop js-top">
			<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
		</div>
		
		<!-- jQuery -->
		<script src="js/jquery.min.js"></script>
		<!-- jQuery Easing -->
		<script src="js/jquery.easing.1.3.js"></script>
		<!-- Bootstrap -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Waypoints -->
		<script src="js/jquery.waypoints.min.js"></script>
		<!-- Stellar Parallax -->
		<script src="js/jquery.stellar.min.js"></script>
		<!-- Carousel -->
		<script src="js/owl.carousel.min.js"></script>
		<!-- Flexslider -->
		<script src="js/jquery.flexslider-min.js"></script>
		<!-- countTo -->
		<script src="js/jquery.countTo.js"></script>
		<!-- Magnific Popup -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<script src="js/magnific-popup-options.js"></script>
		<!-- Count Down -->
		<script src="js/simplyCountdown.js"></script>
		<!-- Main -->
		<script src="js/main.js"></script>
	</body>
</html>