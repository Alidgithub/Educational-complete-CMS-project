<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Education &mdash; Free Website Template, Free HTML5 Template by freehtml5.co</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
		<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
		<meta name="author" content="freehtml5.co" />
		
		<!-- Facebook and Twitter integration -->
		<meta property="og:title" content=""/>
		<meta property="og:image" content=""/>
		<meta property="og:url" content=""/>
		<meta property="og:site_name" content=""/>
		<meta property="og:description" content=""/>
		<meta name="twitter:title" content="" />
		<meta name="twitter:image" content="" />
		<meta name="twitter:url" content="" />
		<meta name="twitter:card" content="" />
		
		<!-- Animate.css -->
		<link rel="stylesheet" href="css/animate.css">
		<!-- Icomoon Icon Fonts-->
		<link rel="stylesheet" href="css/icomoon.css">
		<!-- Bootstrap  -->
		<link rel="stylesheet" href="css/bootstrap.css">
		<!-- Magnific Popup -->
		<link rel="stylesheet" href="css/magnific-popup.css">
		<!-- Owl Carousel  -->
		<link rel="stylesheet" href="css/owl.carousel.min.css">
		<link rel="stylesheet" href="css/owl.theme.default.min.css">
		<!-- Flexslider  -->
		<link rel="stylesheet" href="css/flexslider.css">
		<!-- Pricing -->
		<link rel="stylesheet" href="css/pricing.css">
		<!-- Theme style  -->
		<link rel="stylesheet" href="css/style.css">
		<!-- Modernizr JS -->
		<script src="js/modernizr-2.6.2.min.js"></script>
		<!-- FOR IE9 below -->
	</head>
	<body>
		
		<div class="fh5co-loader"></div>
		
		<div id="page">
			<?php include("include/header.php") ?>
			
			<aside id="fh5co-hero">
				<div class="flexslider">
					<ul class="slides">
						<li style="background-image: url(images/img_bg_4.jpg);">
							<div class="overlay-gradient"></div>
							<div class="row">
								<div class="col-md-8 col-md-offset-2 text-center slider-text">
									<div class="slider-text-inner">
										<h1 class="heading-section">About Us</h1>
										<h2>Free html5 templates Made by <a href="http://freehtml5.co/" target="_blank">freehtml5.co</a></h2>
									</div>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</aside>
			<div class="row">
				<div id="fh5co-about">
					<div class="col-md-6 animate-box">
						<span>About Our College</span>
						<h2>Welcome to Kuli Chowrasta College of Education</h2>
						<p>Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat cauctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per Mauris in erat justo.</p>
						<p>Nullam ac urna eu felis dapibus condimentum sit amet a augue. Sed non neque elit. Sed ut imperdiet nisi. Proin condimentum fermentum nunc. Etiam pharetra, erat sed.</p>
						<p>Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat cauctor eu in elit. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per Mauris in erat justo.</p>
					</div>
					<div class="col-md-6">
						<img class="img-responsive" src="images/img_bg_2.jpg" alt="Free HTML5 Bootstrap Template">
					</div>
				</div>
			</div>
			<br><br><br>
			<div class="row">
				<div class="col-md-12 animate-box">
					<!-- <span class="text-primary">About Our College</span> -->
					<h1><b>Know the<span style="color: red;"> Rules and Regulation</span></b></h1>
					<h3>We always try to inculcate rules and disciplines to our students because we believe that a good educated human being is what the society needs and always important.</h3>
					<ul style="color: black;">
						<li>
							A student admitted in Khargram College Of Education should maintain an ethos of commitment to a professional Programme.
						</li>
						<li>
							He/She is expected to achieve all the good manners and maintain those strictly.
						</li>
						<li>
							According to the West Bengal Board of Primary Education(WBBPE) and NCTE the trainees must attend 75% classes or he/she will be friend for least attendance.
						</li>
						<li>
							The trainees must  attend all the practice teaching classes. No excuses without serious issues will be granted.
						</li>
						<li>
							A trainee must also present in all college functions.
						</li>
						<li>
							Prion permission is required from the principal for any holiday.
						</li>
						<li>
							Every student is expected to make the best use of the college library.
						</li>
						<li>
							Every student is told to take the preliminary computer course class.
						</li>
						<li>
							There will be some class tests and two semester exams. Trainee must have to sit all of them.
						</li>
						<li>
							Our college strictly maintain the anti-ragging rule. So any incidents related to ragging, tearing or violence must not be tolerated.
						</li>
					</ul>
				</div>
			</div>
			<br><br><br><br>
			<div id="fh5co-counter" class="fh5co-counters" style="background-image: url(images/img_bg_4.jpg);" data-stellar-background-ratio="0.5">
				<div class="overlay"></div>
				<div class="row">
					<div class="col-md-10 col-md-offset-1">
						<div class="row">
							<div class="col-md-3 col-sm-6 text-center animate-box">
								<span class="icon"><i class="icon-world"></i></span>
								<span class="fh5co-counter js-counter" data-from="0" data-to="3297" data-speed="5000" data-refresh-interval="50"></span>
								<span class="fh5co-counter-label">Foreign Followers</span>
							</div>
							<div class="col-md-3 col-sm-6 text-center animate-box">
								<span class="icon"><i class="icon-study"></i></span>
								<span class="fh5co-counter js-counter" data-from="0" data-to="3700" data-speed="5000" data-refresh-interval="50"></span>
								<span class="fh5co-counter-label">Students Enrolled</span>
							</div>
							<div class="col-md-3 col-sm-6 text-center animate-box">
								<span class="icon"><i class="icon-bulb"></i></span>
								<span class="fh5co-counter js-counter" data-from="0" data-to="5034" data-speed="5000" data-refresh-interval="50"></span>
								<span class="fh5co-counter-label">Classes Complete</span>
							</div>
							<div class="col-md-3 col-sm-6 text-center animate-box">
								<span class="icon"><i class="icon-head"></i></span>
								<span class="fh5co-counter js-counter" data-from="0" data-to="1080" data-speed="5000" data-refresh-interval="50"></span>
								<span class="fh5co-counter-label">Certified Teachers</span>
							</div>
						</div>
					</div>
				</div>
			</div>
			<br><br><br>
			<?php include("include/footer.php") ?>
			<div class="gototop js-top">
				<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
			</div>
		</div>
		<!-- jQuery -->
		<script src="js/jquery.min.js"></script>
		<!-- jQuery Easing -->
		<script src="js/jquery.easing.1.3.js"></script>
		<!-- Bootstrap -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Waypoints -->
		<script src="js/jquery.waypoints.min.js"></script>
		<!-- Stellar Parallax -->
		<script src="js/jquery.stellar.min.js"></script>
		<!-- Carousel -->
		<script src="js/owl.carousel.min.js"></script>
		<!-- Flexslider -->
		<script src="js/jquery.flexslider-min.js"></script>
		<!-- countTo -->
		<script src="js/jquery.countTo.js"></script>
		<!-- Magnific Popup -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<script src="js/magnific-popup-options.js"></script>
		<!-- Count Down -->
		<script src="js/simplyCountdown.js"></script>
		<!-- Main -->
		<script src="js/main.js"></script>
	</body>
</html>