<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Education &mdash; Free Website Template, Free HTML5 Template by freehtml5.co</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
		<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
		<meta name="author" content="freehtml5.co" />
		<!-- Facebook and Twitter integration -->
		<meta property="og:title" content=""/>
		<meta property="og:image" content=""/>
		<meta property="og:url" content=""/>
		<meta property="og:site_name" content=""/>
		<meta property="og:description" content=""/>
		<meta name="twitter:title" content="" />
		<meta name="twitter:image" content="" />
		<meta name="twitter:url" content="" />
		<meta name="twitter:card" content="" />
		
		<!-- Animate.css -->
		<link rel="stylesheet" href="css/animate.css">
		<!-- Icomoon Icon Fonts-->
		<link rel="stylesheet" href="css/icomoon.css">
		<!-- Bootstrap  -->
		<link rel="stylesheet" href="css/bootstrap.css">
		<!-- Magnific Popup -->
		<link rel="stylesheet" href="css/magnific-popup.css">
		<!-- Owl Carousel  -->
		<link rel="stylesheet" href="css/owl.carousel.min.css">
		<link rel="stylesheet" href="css/owl.theme.default.min.css">
		<!-- Flexslider  -->
		<link rel="stylesheet" href="css/flexslider.css">
		<!-- Pricing -->
		<link rel="stylesheet" href="css/pricing.css">
		<!-- Theme style  -->
		<link rel="stylesheet" href="css/style.css">
		<!-- Modernizr JS -->
		<script src="js/modernizr-2.6.2.min.js"></script>
		<!-- FOR IE9 below -->
		<!--[if lt IE 9]>
		<script src="js/respond.min.js"></script>
		<![endif]-->
	</head>
	<body>
		<div class="fh5co-loader"></div>
		
		<div id="page">
			<?php include("include/header.php") ?>
			<aside id="fh5co-hero">
				<div class="flexslider">
					<ul class="slides">
						<li style="background-image: url(images/img_bg_4.jpg);">
							<div class="overlay-gradient"></div>
							<div class="row">
								<div class="col-md-8 col-md-offset-2 text-center slider-text">
									<div class="slider-text-inner">
										<h1 class="heading-section">B.ed Student Table</h1>
										<h2>All B.ed Student Data <a href="http://freehtml5.co/" target="_blank">Kuli Chowrasta</a></h2>
									</div>
								</div>
							</div>
						</li>
					</ul>
				</div>
			</aside>
			<br><br>
			<div class="row text-center">
				<h2><span>B.ed Student Table</span></h2>
			</div>
			<nav class="fh5co-nav" role="navigation">
				<div class="top-menu text-primary">
					<div class="row">
						<div class="col-xs-12 text-left menu-1">
							<ul>
								<li class="active"><a href="#">All</a></li>
								<li><a href="#">2018-2020</a></li>
								<li><a href="#">2019-2021</a></li>
								<li><a href="#">2020-2022</a></li>
								<li><a href="#">2021-2023</a></li>
							</ul>
						</div>
						
					</div>
				</div>
			</nav>
			<table class="table table-responsive">
				<thead class="text-primary">
					<tr>
						<th>SL.</th>
						<th>NAME OF THE STUDENT ADMITTED</th>
						<th>FATHER'S NAME</th>
						<th>ADDRESS</th>
						<th>CATEGORY (GEN/SC/ST/ OBC/OTHERS)</th>
						<th>YEAR OF ADMISSION</th>
						<th>RESULT</th>
						<th>1ST SEM PERCENTAGE</th>
						<th>2ND SEM PERCENTAGE</th>
						<th>MOBILE NO.</th>
						<th>ADMISSION FEE(RECIEPT NO, DATE & AMOUNT)</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td style="color: black;">1</td>
						<td>ALID SHAIKH</td>
						<td>SEIKH RAFIKUL ISLAM</td>
						<td>VILL-KULI CHOWRASTA, P.O-KULI KANDI, P.S-BURWAN, DIST- MURSHIDABAD, PIN-742168</td>
						<td>GENERAL</td>
						<td>2019</td>
						<td>87%</td>
						<td>77%</td>
						<td>75%</td>
						<td>+91 8089674601</td>
						<td>12000</td>
					</tr>
					<tr>
						<td style="color: black;">2</td>
						<td>ALID SHAIKH</td>
						<td>SEIKH RAFIKUL ISLAM</td>
						<td>VILL-KULI CHOWRASTA, P.O-KULI KANDI, P.S-BURWAN, DIST- MURSHIDABAD, PIN-742168</td>
						<td>GENERAL</td>
						<td>2019</td>
						<td>87%</td>
						<td>77%</td>
						<td>75%</td>
						<td>+91 8089674601</td>
						<td>12000</td>
					</tr>
					<tr>
						<td style="color: black;">3</td>
						<td>ALID SHAIKH</td>
						<td>SEIKH RAFIKUL ISLAM</td>
						<td>VILL-KULI CHOWRASTA, P.O-KULI KANDI, P.S-BURWAN, DIST- MURSHIDABAD, PIN-742168</td>
						<td>GENERAL</td>
						<td>2019</td>
						<td>87%</td>
						<td>77%</td>
						<td>75%</td>
						<td>+918089674601</td>
						<td>12000</td>
					</tr>
					<tr>
						<td style="color: black;">4</td>
						<td>ALID SHAIKH</td>
						<td>SEIKH RAFIKUL ISLAM</td>
						<td>VILL-KULI CHOWRASTA, P.O-KULI KANDI, P.S-BURWAN, DIST- MURSHIDABAD, PIN-742168</td>
						<td>GENERAL</td>
						<td>2019</td>
						<td>87%</td>
						<td>77%</td>
						<td>75%</td>
						<td>+91 8089674601</td>
						<td>12000</td>
					</tr>
					
				</tbody>
			</table>
			
			<br><br><br><br>
			<?php include("include/footer.php") ?>
		</div>
		<div class="gototop js-top">
			<a href="#" class="js-gotop"><i class="icon-arrow-up"></i></a>
		</div>
		
		<!-- jQuery -->
		<script src="js/jquery.min.js"></script>
		<!-- jQuery Easing -->
		<script src="js/jquery.easing.1.3.js"></script>
		<!-- Bootstrap -->
		<script src="js/bootstrap.min.js"></script>
		<!-- Waypoints -->
		<script src="js/jquery.waypoints.min.js"></script>
		<!-- Stellar Parallax -->
		<script src="js/jquery.stellar.min.js"></script>
		<!-- Carousel -->
		<script src="js/owl.carousel.min.js"></script>
		<!-- Flexslider -->
		<script src="js/jquery.flexslider-min.js"></script>
		<!-- countTo -->
		<script src="js/jquery.countTo.js"></script>
		<!-- Magnific Popup -->
		<script src="js/jquery.magnific-popup.min.js"></script>
		<script src="js/magnific-popup-options.js"></script>
		<!-- Count Down -->
		<script src="js/simplyCountdown.js"></script>
		<!-- Main -->
		<script src="js/main.js"></script>
		<script>
		var d = new Date(new Date().getTime() + 1000 * 120 * 120 * 2000);
		// default example
		simplyCountdown('.simply-countdown-one', {
		year: d.getFullYear(),
		month: d.getMonth() + 1,
		day: d.getDate()
		});
		//jQuery example
		$('#simply-countdown-losange').simplyCountdown({
		year: d.getFullYear(),
		month: d.getMonth() + 1,
		day: d.getDate(),
		enableUtc: false
		});
		</script>
	</body>
</html>