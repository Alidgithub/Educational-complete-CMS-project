<?php
if (isset($_GET['fileName']) && !empty($_GET['fileName'])) {
	$filename = "admin/upload/".$_GET['fileName'];
	$aaa = mime_content_type($filename);
	// exit();
	header('Content-Type: "'.$aaa.'"');
	header('Content-Disposition: attachment; filename="'.basename($filename).'"');
	header("Content-Transfer-Encoding: binary");
	header('Expires: 0');
	header('Pragma: no-cache');
	header("Content-Length: ".filesize($filename));
	readfile($filename);
exit($aaa);
}else{
echo "File not found!!";
}





?>