<?php
//delete user//
session_start();
include"action/config.php";

function SuccessAlert($messege){
  $_SESSION['SuccessAlert'] = $messege;
}

if (isset($_GET['img_id']) && isset($_GET['catid'])) {
  $img_id = $_GET['img_id'];
  $catid = $_GET['catid'];
}

$sql1 = "SELECT * FROM gallery WHERE photo_id = '$img_id'";
$result2 = mysqli_query($conn, $sql1) or die("Query Failed");
$row = mysqli_fetch_assoc($result2);
unlink("upload/".$row['image_url']);

 $sql = " DELETE FROM gallery WHERE photo_id='$img_id'; ";
 $sql.= "UPDATE photo_category SET total_images = total_images -1 WHERE id = '$catid'";
 $result = mysqli_multi_query($conn, $sql);
 if ($result) {
     header("Location: photo.php");
     SuccessAlert("Image delete sucessfull");
 }
?>