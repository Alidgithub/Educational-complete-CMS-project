<?php 
include "header.php";
include "action/config.php";

?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-10">
                  <h1 class="admin-heading">All Courses</h1>
              </div>
              <div class="col-md-2">
                  <a class="add-new" href="add-courses.php">add course</a>
              </div>
              <div class="col-md-12">

                <?php
                $sql = "SELECT * FROM courses ORDER BY course_id DESC";
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0 ) :
                ?>
                  <table class="content-table">
                      <thead>
                          <th>S.No.</th>
                          <th>Course Tittle</th>
                          <th>Addmission Fee</th>
                          <th>Course duration</th>
                          <th>Total fee</th>
                          <th>Edit</th>
                          <th>Delete</th>
                      </thead>
                      <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                          <tr>
                              <td class='id'> <?php echo $row['course_id']; ?> </td>
                              <td><?php echo $row['course_name']; ?></td>
                              <td><?php echo $row['admission_fee']; ?></td>
                              <td><?php echo $row['duration']; ?></td>
                              <td><?php echo $row['total_fees']; ?></td>
                              <td class='edit'><a href='update-courses.php?courseId=<?php echo $row['course_id']; ?>'><i class='fa fa-edit'></i></a></td>
                              <td class='delete'><a onclick="return confirm('Are you sure?')" href='delete-courses.php?courseId=<?php echo $row['course_id']; ?>'><i class='fa fa-trash-o'></i></a></td>
                          </tr>  
                        <?php endwhile ?>
                      </tbody>
                  </table>
                <?php endif ?>
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
