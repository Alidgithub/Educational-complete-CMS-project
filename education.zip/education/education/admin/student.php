<?php include "header.php"; ?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-8">
                  <h1 class="admin-heading">All Student</h1>
              </div>
              <div class="col-md-4" style="margin-bottom: 14px;">
                <form class="search-post form-search" action="search.php" method ="GET">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Search .....">
                        <span class="input-group-btn">
                            <button type="submit" class="btn btn-danger">Search</button>
                        </span>
                    </div>
                </form>
              </div>
              <div class="col-md-12 table-responsive">
                  <table class="content-table">
                      <thead>
                          <th>S.No.</th>
                          <th>Photo</th>
                          <th>Student Name</th>
                          <th>Father's Name</th>
                          <th>Date of Birth </th>
                          <th>Edit</th>
                          <th>Delete</th>
                          <th>View</th>
                      </thead>
                      <tbody>
                          <tr>
                              <td class='id'>1</td>
                              <td>Lorem ipsum</td>
                              <td>Html</td>
                              <td>Html</td>
                              <td>01 Nov, 2019</td>
                              <td class='edit'><a href='update-student.php'><i class='fa fa-edit'></i></a></td>

                              <td class='delete'><a href='delete-student.php'><i class='fa fa-trash-o'></i></a></td>

                              <td class='delete'><a href='student-view.php'><i class="fa fa-eye fa-lg"></i></a></td>
                          </tr>
                          <tr>
                              <td class='id'>1</td>
                              <td>Lorem ipsum</td>
                              <td>Html</td>
                              <td>Html</td>
                              <td>01 Nov, 2019</td>
                              <td class='edit'><a href='update-student.php'><i class='fa fa-edit'></i></a></td>

                              <td class='delete'><a href='delete-student.php'><i class='fa fa-trash-o'></i></a></td>

                              <td class='delete'><a href='student-view.php'><i class="fa fa-eye fa-lg"></i></a></td>
                          </tr>
                          <tr>
                              <td class='id'>1</td>
                              <td>Lorem ipsum</td>
                              <td>Html</td>
                              <td>Html</td>
                              <td>01 Nov, 2019</td>
                              <td class='edit'><a href='update-student.php'><i class='fa fa-edit'></i></a></td>

                              <td class='delete'><a href='delete-student.php'><i class='fa fa-trash-o'></i></a></td>

                              <td class='delete'><a href='student-view.php'><i class="fa fa-eye fa-lg"></i></a></td>
                          </tr>
                          <tr>
                              <td class='id'>1</td>
                              <td>Lorem ipsum</td>
                              <td>Html</td>
                              <td>Html</td>
                              <td>01 Nov, 2019</td>
                              <td class='edit'><a href='update-student.php'><i class='fa fa-edit'></i></a></td>

                              <td class='delete'><a href='delete-student.php'><i class='fa fa-trash-o'></i></a></td>

                              <td class='delete'><a href='student-view.php'><i class="fa fa-eye fa-lg"></i></a></td>
                          </tr>
                      </tbody>
                  </table>
                  <ul class='pagination admin-pagination'>
                      <li class="active"><a>1</a></li>
                      <li><a>2</a></li>
                      <li><a>3</a></li>
                  </ul>
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
