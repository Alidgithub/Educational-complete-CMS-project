<?php
include "header.php"; 
include "action/config.php"; 

?>
  <div id="admin-content">
      <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <h1 class="admin-heading">Update Management</h1>
             </div>
              <div class="col-md-offset-3 col-md-6">
                <?php
                if (isset($_GET['managId'])) {
                  $manage_id = $_GET['managId'];
                }else{
                  header("Location: management.php");
                }
                    $sql = "SELECT * FROM Management WHERE manage_id = $manage_id";
                    $result = mysqli_query($conn, $sql);
                    $row = mysqli_fetch_assoc($result);
                ?>
                  <!-- Form -->
                  <form  action="action/admin-action.php" method="POST">
                      <div class="form-group">
                          <input type="hidden" name="manage_id" value="<?php echo $row['manage_id'] ?>" class="form-control" autocomplete="off">
                      </div>
                      <div class="form-group">
                          <label for="post_title">Name</label>
                          <input type="text" name="name" value="<?php echo $row['name']; ?>" class="form-control" autocomplete="off">
                      </div>
                      <div class="form-group">
                          <label for="post_title">DESIGNATION</label>
                          <input type="text" name="designation" value="<?php echo trim($row['desig']); ?>" class="form-control" autocomplete="off">
                      </div>
                       <div class="form-group">
                          <label for="post_title">Phone No.</label>
                          <input type="number" name="mobile" value="<?php echo $row['mobile']; ?>" class="form-control" autocomplete="off">
                      </div>
                      <input type="submit" name="update_management" class="btn btn-primary" value="Update" required />
                  </form>
                  <!--/Form -->
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
