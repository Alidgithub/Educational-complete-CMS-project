<?php
function csrf_token(){
    $token = bin2hex(random_bytes(32));
    $_SESSION['token'] = $token;
    return $token;
}

function debug($arg){
	echo "<Pre>";
	print_r($arg);
	echo "</Pre>";
	exit();
}




?>