<?php
$conn = mysqli_connect("localhost", "root", "", "college_project") or die("connection faild:" . mysqli_connect_error());


?>