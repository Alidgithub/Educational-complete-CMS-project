<?php 
include "header.php"; 
include "action/config.php"; 

?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-12">
                  <h1 class="admin-heading">Update Photo Category</h1>
              </div>
              <div class="col-md-offset-3 col-md-6">
                  <!-- Form Start -->
                  <?php
                  if (isset($_GET['id'])) {
                    $cat_id = $_GET['id'];
                  }else{
                    header("Location: photo-category.php");
                    die();
                  }
                  $sql = "SELECT * FROM photo_category WHERE id = $cat_id ";
                  $result = mysqli_query($conn, $sql);
                  $row = mysqli_fetch_assoc($result);
                  ?>
                  <form action="action/admin-action.php" method="POST" autocomplete="off">
                      <div class="form-group">
                          <label>Photo Category Name</label>
                          <input type="text" name="cat" class="form-control" placeholder="Category Name" value="<?php echo $row['category_name']; ?>">
                      </div>
                      <div class="form-group">
                          <input type="hidden" name="cat_id" class="form-control" placeholder="Category Name" value="<?php echo $row['id']; ?>">
                      </div>
                      <input type="submit" name="update_photo_category" class="btn btn-primary" value="update" required />
                  </form>
                  <!-- /Form End -->
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
