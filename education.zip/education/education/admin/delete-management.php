<?php
//delete user//
session_start();
include"action/config.php";

function SuccessAlert($messege){
  $_SESSION['SuccessAlert'] = $messege;
}

if (isset($_GET['managId'])) {
  $managId = $_GET['managId'];
}
 $sql = " DELETE FROM Management WHERE manage_id='$managId' ";
 $result = mysqli_query($conn, $sql);
 if ($result) {
     header("location: Management.php");
     SuccessAlert("Management delete sucessfull");
 }