<!DOCTYPE HTML>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<title>Education &mdash; Free Website Template, Free HTML5 Template by freehtml5.co</title>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta name="description" content="Free HTML5 Website Template by freehtml5.co" />
		<meta name="keywords" content="free website templates, free html5, free template, free bootstrap, free website template, html5, css3, mobile first, responsive" />
		<meta name="author" content="freehtml5.co" />
		<meta property="og:title" content=""/>
		<meta property="og:image" content=""/>
		<meta property="og:url" content=""/>
		<meta property="og:site_name" content=""/>
		<meta property="og:description" content=""/>
		<meta name="twitter:title" content="" />
		<meta name="twitter:image" content="" />
		<meta name="twitter:url" content="" />
		<meta name="twitter:card" content="" />
		
		<!-- Bootstrap open -->
		<link rel="stylesheet" href="../css/bootstrap.css">
		<!-- Bootstrap end -->
	</head>
	<body>
		
		<div id="page">
			<?php include("header.php"); ?>
			<div id="fh5co-contact">
				<div class="container">
					<div class="row">
						
						<div class="col-md-12 animate-box">
							<h1>Update Student Details</h1>
							<form action="#">
								<div class="row form-group">
									<div class="col-md-4">
										<label for="fname">Student Name :<span style="color: red;"> *</span></label>
										<input type="text" id="fname" class="form-control" placeholder="Enter Student Name">
									</div>
									<div class="col-md-4">
										<label for="lname">Father's Name :<span style="color: red;"> *</span></label>
										<input type="text" id="lname" class="form-control" placeholder="Enter Father's Name">
									</div>
									<div class="col-md-4">
										<label for="lname">Mother's Name:</label>
										<input type="text" id="lname" class="form-control" placeholder="Enter Mother's Name">
									</div>
									<br><br>
									<div class="col-md-4">
										<label for="fname">Date of Birth :<span style="color: red;"> *</span></label>
										<input type="date" id="fname" class="form-control">
									</div>
									<div class="col-md-4">
										<label for="lname">Blood Group :</label>
										<input type="text" id="lname" class="form-control" placeholder="Enter Blood Group">
									</div>
									<div class="col-md-4">
										<label for="lname">Nationality :<span style="color: red;"> *</span></label>
										<input type="text" id="lname" class="form-control" placeholder="Enter Nationality">
									</div>
									<div class="col-md-4">
										<label for="lname">Session :<span style="color: red;"> *</span></label>
										<input type="text" id="lname" class="form-control" placeholder="2018-2020">
									</div>
									<div class="col-md-4">
										<label for="lname">Religion :</label>
										<input type="text" id="lname" class="form-control" placeholder="Enter Religion">
									</div>
									<div class="col-md-4">
										<label for="lname">Email :<span style="color: red;"> *</span></label>
										<input type="email" id="lname" class="form-control" placeholder="Enter Email">
									</div>
									<div class="col-md-4">
										<label for="lname">Mobile No. :<span style="color: red;"> *</span></label>
										<input type="number" id="lname" class="form-control" placeholder="Enter Mobile No.">
									</div>
									<div class="col-md-4">
										<label for="lname">Guardian's Number :</label>
										<input type="number" id="lname" class="form-control" placeholder="Enter Guardian's Number">
									</div>
									<div class="col-md-4">
										<label for="lname">Aadhaar No. :<span style="color: red;"> *</span></label>
										<input type="number" id="lname" class="form-control" placeholder="Enter Aadhaar No.">
									</div>
									<div class="col-md-4">
										<label for="lname">Subject applied for (B.Ed only) :<span style="color: red;"> *</span></label>
										<input type="text" id="lname" class="form-control" placeholder="Subject applyed for">
									</div>
									<div class="col-md-4">
										<label for="lname">Caste :</label>
										<input type="text" id="lname" class="form-control" placeholder="ST/SC/OBC">
									</div>
									<div class="col-md-4">
										<label for="lname">Last University/Board Pass :<span style="color: red;"> *</span></label>
										<input type="text" id="lname" class="form-control" placeholder="Last University/Board Passed">
									</div>
									<div class="col-md-4">
										<label for="lname">Last University Regn No (Only for BEd student) :<span style="color: red;"> *</span></label>
										<input type="text" id="lname" class="form-control" placeholder="Last University Regn No.">
									</div>
									<div class="col-md-4">
										<label for="lname">Last school name (Only for D.EL.Ed students) :<span style="color: red;"> *</span></label>
										<input type="text" id="lname" class="form-control" placeholder="Last School name">
									</div>
									<div class="col-md-4">
										<p><b>Gender : <span style="color: red;"> *</span></b></p>
										<input type="radio" id="html" name="fav_language" value="HTML">
										<label for="html">Male</label><br>
										<input type="radio" id="css" name="fav_language" value="CSS">
										<label for="css">Female</label><br>
									</div>
									<div class="col-md-4">
										<p><b>Class : <span style="color: red;"> *</span></b></p>
										<input type="radio" id="html" name="fav_language" value="HTML">
										<label for="html">B.Ed</label><br>
										<input type="radio" id="css" name="fav_language" value="CSS">
										<label for="css">D.Ed</label><br>
									</div>
									<div class="col-md-4">
										<p><b>Whether Fresher or Deputed : <span style="color: red;"> *</span></b></p>
										<input type="radio" id="html" name="fav_language" value="HTML">
										<label for="html">Fresher</label><br>
										<input type="radio" id="css" name="fav_language" value="CSS">
										<label for="css">Deputed</label><br>
									</div>
								</div>
								<div class="row form-group">
									<div class="col-md-8">
										<label for="email">Address with pin code <span style="color: red;"> *</span></label>
										<input type="text" id="email" class="form-control" placeholder="Full Address">
									</div>
									<div class="col-md-4">
										<label for="email">Photo copy <span style="color: red;"> *</span></label>
										<input type="file" id="email" class="form-control" placeholder="Your email address">
									</div>
									<div class="col-md-4">
										
									</div>
									<div class="col-md-4">
										<label for="lname">Captcha <span style="color: red;"> *</span></label>
										<input type="number" id="lname" class="form-control" placeholder="Captcha">
									</div>
								</div>
								<div class="table-responsive">
									<table class="table">
										<thead class="text-primary">
											<tr>
												<th>SL.</th>
												<th>Name of the exam</th>
												<th>Board/University</th>
												<th>Year of Pussing</th>
												<th>Full marks</th>
												<th>Marks obtained</th>
												<th>% Marks</th>
											</tr>
										</thead>
										<tbody style="color: black;">
											<tr>
												<td style="color: black;">1</td>
												<td>M.P (Secondary Pass) <span style="color: red;"> *</span></td>
												<td><input class="form-control" type="text" name=""placeholder="Board/University"></td>
												<td><input class="form-control" type="text" name=""placeholder="Year of Pussing"></td>
												<td><input class="form-control" type="text" name=""placeholder="Full marks"></td>
												<td><input class="form-control" type="text" name=""placeholder="Marks obtained"></td>
												<td><input class="form-control" type="text" name=""placeholder="% Marks"></td>
											</tr>
											<tr>
												<td style="color: black;">2</td>
												<td>H.S(Higher Secondary Pass)<span style="color: red;"> *</span></td>
												<td><input class="form-control" type="text" name=""placeholder="Board/University"></td>
												<td><input class="form-control" type="text" name=""placeholder="Year of Pussing"></td>
												<td><input class="form-control" type="text" name=""placeholder="Full marks"></td>
												<td><input class="form-control" type="text" name=""placeholder="Marks obtained"></td>
												<td><input class="form-control" type="text" name=""placeholder="% Marks"></td>
											</tr>
											<tr>
												<td style="color: black;">3</td>
												<td>B.A/B.Sc/B.Com (Honours/Pass)</td>
												<td><input class="form-control" type="text" name=""placeholder="Board/University"></td>
												<td><input class="form-control" type="text" name=""placeholder="Year of Pussing"></td>
												<td><input class="form-control" type="text" name=""placeholder="Full marks"></td>
												<td><input class="form-control" type="text" name=""placeholder="Marks obtained"></td>
												<td><input class="form-control" type="text" name=""placeholder="% Marks"></td>
											</tr>
											<tr>
												<td style="color: black;">4</td>
												<td>M.A/M.Sc/M.Com Pass</td>
												<td><input class="form-control" type="text" name=""placeholder="Board/University"></td>
												<td><input class="form-control" type="text" name=""placeholder="Year of Pussing"></td>
												<td><input class="form-control" type="text" name=""placeholder="Full marks"></td>
												<td><input class="form-control" type="text" name=""placeholder="Marks obtained"></td>
												<td><input class="form-control" type="text" name=""placeholder="% Marks"></td>
											</tr>
											
										</tbody>
									</table>
								</div>
								<div class="form-group">
									<input type="submit" value="Update" class="btn btn-primary">
								</div>
							</form>
						</div>
					</div>
					
				</div>
			</div> <br><br>
			<?php include("footer.php"); ?>
		</div>
	</body>
</html>