<?php include "header.php"; ?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-8">
                  <h1 class="admin-heading">Alid Shaikh</h1>
              </div>
             <!--  <div class="col-md-4" style="margin-bottom: 14px;">
                <form class="search-post form-search" action="search.php" method ="GET">
                    <div class="input-group">
                        <input type="text" name="search" class="form-control" placeholder="Search .....">
                        <span class="input-group-btn">
                            <button type="submit" class="btn btn-danger">Search</button>
                        </span>
                    </div>
                </form>
              </div> -->
              <div class="col-md-12 table-responsive">
                    <table class="content-table">
                      <thead>
                        <!--   <th>Id No. 55</th>
                          <th>Details</th> -->
                      </thead>
                      <tbody>
                          <tr>
                              <td><b>Name :-</b></td>
                              <td>Alid Shaikh</td>
                              <td><b>Father's Name :-</b></td>
                              <td>Alid Shaikh</td>
                          </tr>
                          <tr>
                              <td><b>Mother's Name :-</b></td>
                              <td>Rafikul Islam</td>
                              <td><b>Date of Birth :-</b></td>
                              <td>Rafikul Islam</td>
                          </tr>
                          <tr>
                              <td><b>Blood Group :-</b></td>
                              <td>O+</td>
                              <td><b>Nationality :-</b></td>
                              <td>Indian</td>
                          </tr>
                          <tr>
                              <td><b>Session :-</b></td>
                              <td>2018-2020</td>
                              <td><b>Religion :-</b></td>
                              <td>Islam</td>
                          </tr>
                          <tr>
                              <td><b>Email :-</b></td>
                              <td>Alidsk4@gmail.com</td>
                              <td><b>Mobile No :-</b></td>
                              <td>8089674601</td>
                          </tr>
                          <tr>
                              <td><b>Guardian's Number :-</b></td>
                              <td>9734842267</td>
                              <td><b>Aadhaar No. :-</b></td>
                              <td>334927327886</td>
                          </tr>
                          <tr>
                              <td><b>Subject applied for (B.Ed only) :-</b></td>
                              <td>Alid Shaikh</td>
                              <td><b>Caste :-</b></td>
                              <td>General</td>
                          </tr>
                          <tr>
                              <td><b>Last University/Board Pass :-</b></td>
                              <td>Rafikul Islam</td>
                              <td><b>Last University Regn No (Only for BEd student) :-</b></td>
                              <td>General</td>
                          </tr>
                          <tr>
                              <td><b>Gender :-</b></td>
                              <td>Male</td>
                              <td><b>Class :-</b></td>
                              <td>D.ed</td>
                          </tr>
                          <tr>
                              <td><b>Address with pin code :-</b></td>
                              <td>VILL-KULI CHOWRASTA, P.O-KULI KANDI,
                               P.S-BURWAN, DIST- MURSHIDABAD,
                                PIN-742168</td>
                              <td><b>Whether Fresher or Deputed :-</b></td>
                              <td>Fresher</td>
                          </tr>
                      </tbody>
                  </table>
                </div>
                <div class="col-md-12 table-responsive">
                  <table class="content-table">
                    <thead style="background-color: #1DC87F;">
                      <th>SL.</th>
                      <th>Name of the exam</th>
                      <th>Board/University</th>
                      <th>Year of Pussing</th>
                      <th>Full marks</th>
                      <th>Marks obtained</th>
                      <td>% Marks</td>
                    </thead>
                    <tbody>
                      <tr>
                        <td>1</td>
                        <td>M.P (Secondary Pass)</td>
                        <td>WBHSE</td>
                        <td>2015</td>
                        <td>700</td>
                        <td>404</td>
                        <td>58.89%</td>
                      </tr>
                      <tr>
                        <td>2</td>
                        <td>H.S(Higher Secondary Pass)</td>
                        <td>WBCHSE</td>
                        <td>2017</td>
                        <td>500</td>
                        <td>350</td>
                        <td>59.50%</td>
                      </tr>
                      <tr>
                        <td>3</td>
                        <td>B.A/B.Sc/B.Com (Honours/Pass)</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>4</td>
                        <td>M.A/M.Sc/M.Com Pass</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                      </tr>
                    </tbody>
                  </table>
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
