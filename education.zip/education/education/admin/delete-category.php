<?php
//delete user//
session_start();
include"action/config.php";

function SuccessAlert($messege){
  $_SESSION['SuccessAlert'] = $messege;
}

if (isset($_GET['id'])) {
  $cat_id = $_GET['id'];
}

if ($cat_id == 21) {
header("Location: photo-category.php");
 die();
}else{
  $sql = " DELETE FROM photo_category WHERE id = '$cat_id' ";
  $result = mysqli_query($conn, $sql);
  
  if ($result) {
     header("Location: photo-category.php");
     SuccessAlert("Photo category deleted sucessfully");
   }
 }
?>