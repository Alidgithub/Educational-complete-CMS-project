<?php
include "header.php";
include "action/config.php"; 

if (isset($_GET['notice_id'])) {
  $notice_id = $_GET['notice_id'];
}else{
  header("Location: notice.php");
  die();
}
$sql = "SELECT * FROM notice WHERE id = '$notice_id'";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
?>

  <div id="admin-content">
      <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <h1 class="admin-heading">Update Notice</h1>
             </div>
              <div class="col-md-offset-3 col-md-6">
                  <!-- Form -->
                  <form  action="action/admin-action.php" method="POST" enctype="multipart/form-data">
                      <div class="form-group">
                          <input type="hidden" value="<?php echo $row['id']; ?>" name="notice_id" class="form-control" autocomplete="off" >
                      </div>
                      <div class="form-group">
                          <label for="update_title">Tittle</label>
                          <input type="text" value="<?php echo $row['tittle']; ?>" name="update_notice_title" class="form-control" autocomplete="off" >
                      </div>
                      <div class="form-group">
                          <label for="update_date">Date</label>
                          <input type="date" value="<?php echo date('Y-m-d',strtotime($row['noticeDate'])); ?>" name="update_notice_date" class="form-control" autocomplete="off" >
                      </div>
                      <div class="form-group">
                          <label for="update_description"> Description</label>
                          <textarea name="update_notice_description" class="form-control" rows="5" > <?php echo trim($row['description']); ?> </textarea>
                      </div>
                      <input type="submit" name="update_notice" class="btn btn-primary" value="Update" />
                  </form>
                  <!--/Form -->
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
