<?php include "header.php"; ?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-10">
                  <h1 class="admin-heading">All Document</h1>
              </div>
              <div class="col-md-2">
                  <a class="add-new" href="add-Document.php">Add Document</a>
              </div>
              <div class="col-md-12">
                  <table class="content-table">
                      <thead>
                          <th>S.No.</th>
                          <th>Document Title</th>
                          <!-- <th>Category</th> -->
                          <th>Date</th>
                          <!-- <th>Author</th> -->
                          <th>Edit</th>
                          <th>Delete</th>
                      </thead>
                      <tbody>
                          <tr>
                              <td class='id'>1</td>
                              <td>Lorem ipsum dolor sit amet</td>
                              <!-- <td>Html</td> -->
                              <td>01 Nov, 2019</td>
                              <!-- <td>Admin</td> -->
                              <td class='edit'><a href='update-Document.php'><i class='fa fa-edit'></i></a></td>
                              <td class='delete'><a href='delete-Document.php'><i class='fa fa-trash-o'></i></a></td>
                          </tr>
                      </tbody>
                  </table>
                  <ul class='pagination admin-pagination'>
                      <li class="active"><a>1</a></li>
                      <li><a>2</a></li>
                      <li><a>3</a></li>
                  </ul>
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
