<?php 
include "header.php"; 
include "action/function.php";
?>
  <div id="admin-content">
      <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <h1 class="admin-heading">Add New Course</h1>
             </div>
              <div class="col-md-offset-3 col-md-6">
                  <!-- Form -->
                  <form  action="action/admin-action.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                      <div class="form-group">
                          <label for="Course name">Course name</label>
                          <input type="text" name="course_name" class="form-control">
                      </div>
                      <div class="form-group">
                          <label for="Admission fees">Admission fees</label>
                          <input type="number" name="admission_fees" class="form-control">
                      </div>
                      <div class="form-group">
                          <label for="Duration">Duration as month</label>
                          <input type="number" name="duration" class="form-control">
                      </div>
                      <div class="form-group">
                          <label for="Total fees">Total fees</label>
                          <input type="number" name="total_fees" class="form-control">
                      </div>
                        <div class="form-group">
                          <label for="description"> Description</label>
                          <textarea name="description" class="form-control" rows="4"></textarea>
                      </div>
                      <div class="form-group">
                          <label for="exampleInputPassword1">Course reletade image</label>
                          <input type="file" name="course_img">
                      </div>
                      <input type="submit" name="add_course" class="btn btn-primary" value="Add" required />
                  </form>
                  <!--/Form -->
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
