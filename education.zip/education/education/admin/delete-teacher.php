<?php
//delete user//
session_start();
include"action/config.php";

function SuccessAlert($messege){
  $_SESSION['SuccessAlert'] = $messege;
}

if (isset($_GET['techer_id'])) {
  $techer_id = $_GET['techer_id'];
}

$sql1 = "SELECT techer_id, img_url FROM Teachers WHERE techer_id = '$techer_id'";
$result2 = mysqli_query($conn, $sql1) or die("Query Failed");
$row = mysqli_fetch_assoc($result2);
unlink("upload/teacher/".$row['img_url']);

 $sql = " DELETE FROM Teachers WHERE techer_id = '$techer_id' ";
 $result = mysqli_query($conn, $sql);
 if ($result) {
     header("Location: teacher.php");
     SuccessAlert("Teacher profile delete sucessfull");
 }
?>