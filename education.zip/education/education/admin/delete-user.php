<?php
//delete user//
session_start();
include"action/config.php";

function SuccessAlert($messege){
  $_SESSION['SuccessAlert'] = $messege;
}

if (isset($_GET['id'])) {
  $userId = $_GET['id'];
}
 $sql = " DELETE FROM admin_login WHERE id='$userId' ";
 $result = mysqli_query($conn, $sql);
 if ($result) {
     header("location: users.php");
     SuccessAlert("User delete sucessfull");
 }

// session_start();
// include "action/config.php";

// Check if user is logged in and has appropriate role
// if (!isset($_SESSION['id']) || $_SESSION['role'] != 1) {
//     header("Location: login.php");
//     exit();
// }

// // Check if user has clicked the delete button and has provided a valid user ID
// if (isset($_GET['id'])) {
//     $userId = mysqli_real_escape_string($conn, $_GET['id']);

//     // Prepare and execute the delete query
//     $stmt = mysqli_prepare($conn, "DELETE FROM admin_login WHERE id = ?");
//     mysqli_stmt_bind_param($stmt, "i", $userId);
//     mysqli_stmt_execute($stmt);
//     $result = mysqli_stmt_affected_rows($stmt);
//     mysqli_stmt_close($stmt);

//     if ($result > 0) {
//         header("Location: users.php");
//         exit();
//     } else {
//         echo "Error deleting user";
//     }
// }


?>