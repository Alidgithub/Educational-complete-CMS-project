<?php
include "header.php"; 
include "action/config.php"; 

?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-9">
                  <h1 class="admin-heading">All Management</h1>
              </div>
              <div class="col-md-3">
                  <a class="add-new" href="add-management.php">add New Management</a>
              </div>
              <div class="col-md-12">

                <?php
                    $sql = "SELECT * FROM Management ORDER BY manage_id DESC";
                    $result = mysqli_query($conn, $sql);
                    if (mysqli_num_rows($result) > 0 ) :
                ?>
                  <table class="content-table">
                      <thead>
                          <th>S.No.</th>
                          <th>Name</th>
                          <th>DESIGNATION</th>
                          <th>Phone No.</th>
                          <th>Edit</th>
                          <th>Delete</th>
                      </thead>
                      <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                          <tr>
                              <td class='id'><?= $row['manage_id']; ?></td>
                              <td><?= strtoupper($row['name']); ?></td>
                              <td><?= strtoupper($row['desig']); ?></td>
                              <td>+91 <?= $row['mobile']; ?></td>
                              <td class='edit'><a href='update-management.php?managId=<?= $row['manage_id']; ?>'><i class='fa fa-edit'></i></a></td>
                              <td class='delete'><a onclick="return confirm('Are you sure?')" href='delete-management.php?managId=<?= $row['manage_id']; ?>'><i class='fa fa-trash-o'></i></a></td>
                          </tr>
                        <?php endwhile ?>
                      </tbody>
                  </table>
                <?php endif ?>
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
