<?php
include "header.php"; 
include "action/config.php";
if (!isset($_GET['techer_id']) || empty($_GET['techer_id'])) {
    header("Location: teacher.php");
    exit();
}
$techer_id = $_GET['techer_id'];

$sql = "SELECT * FROM Teachers WHERE techer_id = '$techer_id' "; 
 $result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_assoc($result);
?>
  <div id="admin-content">
      <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <h1 class="admin-heading">Update Teacher</h1>
             </div>
              <div class="col-md-offset-3 col-md-6">
                  <!-- Form -->
                  <form  action="action/admin-action.php" method="POST" enctype="multipart/form-data">
                      <div class="form-group">
                        <div class="form-group">
                          <input type="hidden" name="teacherId" value="<?php echo $row['techer_id']; ?>" class="form-control">
                      </div>
                          <label for="post_title">Name</label>
                          <input type="text" name="name" value="<?php echo $row['name']; ?>" class="form-control" >
                      </div>
                      <div class="form-group">
                          <label for="post_title">Subject</label>
                          <input type="text" name="subject" value="<?php echo $row['subject']; ?>" class="form-control" >
                      </div>
                      <div class="form-group">
                          <label for="post_title">Facebook profile link</label>
                          <input type="text" name="fbLink" value="<?php echo $row['fb_link']; ?>" class="form-control" placeholder="Optional">
                      </div>
                      <div class="form-group">
                          <label for="post_title">twitter profile link</label>
                          <input type="text" name="twitterLink" value="<?php echo $row['twitter_link']; ?>" class="form-control" placeholder="Optional">
                      </div>
                      <div class="form-group">
                          <label for="exampleInputPassword1">About Himself</label>
                          <textarea name="about_teacher" class="form-control" rows="5"> <?php echo trim($row['about_himself']); ?> </textarea>
                      </div>
                      <div class="form-group">
                          <label for="exampleInputPassword1">Post image</label>
                          <input type="file" name="new_image" >
                          <img src="upload/teacher/<?php echo $row['img_url'] ?>" height="150px;">
                      </div>
                      <input type="submit" name="updateTeacher" class="btn btn-primary" value="Update" required />
                  </form>
                  <!--/Form -->
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
