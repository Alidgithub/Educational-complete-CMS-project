<?php
//delete user//
session_start();
include"action/config.php";

function SuccessAlert($messege){
  $_SESSION['SuccessAlert'] = $messege;
}

if (isset($_GET['notice_id'])) {
  $notice_id = $_GET['notice_id'];
}
 $sql = " DELETE FROM notice WHERE id='$notice_id' ";
 $result = mysqli_query($conn, $sql);
 if ($result) {
     header("Location: notice.php");
     SuccessAlert("Notice delete sucessfull");
 }
?>