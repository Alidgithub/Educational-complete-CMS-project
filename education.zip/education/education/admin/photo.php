<?php
include "header.php";
include "action/config.php";

?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-10">
                <h1 class="admin-heading">All Photos</h1>
            </div>
            <div class="col-md-2">
                <a class="add-new" href="add-photo.php">add Photo</a>
            </div>
            <div class="col-md-12">
                <?php
                $sql = "SELECT g.photo_id, g.tittle, pc.category_name, g.photo_cat_id FROM gallery g LEFT JOIN photo_category pc ON g.photo_cat_id = pc.id ORDER BY g.photo_id DESC";
                $result = mysqli_query($conn, $sql);
                if (mysqli_num_rows($result) > 0 ) :
                
                ?>
                <table class="content-table">
                    <thead>
                        <th>S.No.</th>
                        <th>Photo Tittle</th>
                        <th>Photo Category Name</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </thead>
                    <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                    <tbody>
                        <tr>
                            <td class='id'><?php echo $row['photo_id']; ?></td>
                            <td><?php echo $row['tittle']; ?></td>
                            <td><?php echo $row['category_name']; ?></td>
                            <td class='edit'><a href='update-photo.php?img_id=<?php echo $row['photo_id']; ?>'><i class='fa fa-edit'></i></a></td>
                            <td class='delete'><a onclick="return confirm('Are you sure?')" href='delete-photo.php?img_id=<?php echo $row['photo_id']; ?>&catid=<?php echo $row['photo_cat_id']; ?>'><i class='fa fa-trash-o'></i></a></td>
                        </tr>
                    </tbody>
                <?php endwhile ?>
                </table>
            <?php endif ?>
                <ul class='pagination admin-pagination'>
                    <li class="active"><a>1</a></li>
                    <li><a>2</a></li>
                    <li><a>3</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php include "footer.php"; ?>
