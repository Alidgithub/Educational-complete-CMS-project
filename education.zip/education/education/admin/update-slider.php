<?php
include "header.php"; 
include "action/config.php";
if (!isset($_GET['sliderId']) || empty($_GET['sliderId'])) {
     header("Location: slider.php");
     exit();
 }
    $sliderId = $_GET['sliderId'];

 $sql = "SELECT tittle, sub_tittle, slider_id, img_url FROM slider WHERE slider_id = '$sliderId' "; 
 $result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_assoc($result);

?>
<div id="admin-content">
  <div class="container">
  <div class="row">
    <div class="col-md-12">
        <h1 class="admin-heading">Update Slider</h1>
    </div>
    <div class="col-md-offset-3 col-md-6">
        <!-- Form for show edit-->
        <form action="action/admin-action.php" method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <input type="hidden" name="sliderId"  class="form-control" value="<?php echo $row['slider_id']; ?>">
            </div>
            <div class="form-group">
                <label for="exampleInputTile">Title</label>
                <input type="text" name="tittle"  class="form-control" id="exampleInputUsername" value="<?php echo $row['tittle']; ?>">
            </div>
            <div class="form-group">
                <label for="exampleInputTile">Sub-Title</label>
                <input type="text" name="sub_tittle"  class="form-control" id="exampleInputUsername" value="<?php echo $row['sub_tittle']; ?>">
            </div>
            <div class="form-group">
                <label for="">Post image</label>
                <input type="file" name="new_image">
                <img  src="upload/<?php echo $row['img_url']; ?>" height="150px">
                <input type="hidden" name="old_image" value="<?php echo $row['img_url']; ?>">
            </div>
            <input type="submit" name="update_slider" class="btn btn-primary" value="Update" />
        </form>
        <!-- Form End -->
      </div>
    </div>
  </div>
</div>
<?php include "footer.php"; ?>
