<?php
include "header.php"; 
include "action/config.php"; 

?>
<div id="admin-content">
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <h1 class="admin-heading">All Categories</h1>
            </div>
            <div class="col-md-3">
                <a class="add-new" href="add-photo-category.php">add Photo category</a>
            </div>
            <div class="col-md-12">
                <?php
                $sql = "SELECT * FROM photo_category ORDER BY id DESC ";
                $result = mysqli_query($conn, $sql);
                if ($result) :
                ?>
                <table class="content-table">
                    <thead>
                        <th>S.No.</th>
                        <th>Category Name</th>
                        <th>No. of Photos</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </thead>
                    <?php
                    while ($row = mysqli_fetch_assoc($result)) : ?>
                    <tbody>
                        <tr>
                            <td class='id'><?php echo $row['id']; ?></td>
                            <td><?php echo $row['category_name']; ?></td>
                            <td><?php echo $row['total_images']; ?></td>
                            <td class='edit'><a href='update-photo-category.php?id=<?php echo $row['id']; ?>'><i class='fa fa-edit'></i></a></td>
                            <td class='delete'><a onclick="return confirm('Are you sure?');" href='delete-category.php?id=<?php echo $row['id']; ?>'><i class='fa fa-trash-o'></i></a></td>
                        </tr>
                    </tbody>
                <?php endwhile ?>
                </table>
            <?php endif ?>
                <ul class='pagination admin-pagination'>
                    <li class="active"><a>1</a></li>
                    <li><a>2</a></li>
                    <li><a>3</a></li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php include "footer.php"; ?>
