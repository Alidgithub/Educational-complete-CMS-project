<?php
//delete user//
session_start();
include"action/config.php";

function SuccessAlert($messege){
  $_SESSION['SuccessAlert'] = $messege;
}

if (isset($_GET['courseId'])) {
  $courseId = $_GET['courseId'];
}

$sql3 = "SELECT course_id, img_url FROM courses WHERE course_id = '$courseId'";
$result3 = mysqli_query($conn, $sql3);
$row3 = mysqli_fetch_assoc($result3);
$old_image = $row3['img_url'];
unlink("upload/course/".$old_image);

 $sql = " DELETE FROM courses WHERE course_id = '$courseId' ";
 $result = mysqli_query($conn, $sql);
 if ($result) {
     header("Location: courses.php");
     SuccessAlert("Course deleted sucessfull.");
 }

?>