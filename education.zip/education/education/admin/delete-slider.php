<?php
//delete user//
session_start();
include"action/config.php";

function SuccessAlert($messege){
  $_SESSION['SuccessAlert'] = $messege;
}

if (isset($_GET['sliderId'])) {
  $sliderId = $_GET['sliderId'];
}

$sql1 = "SELECT * FROM slider WHERE slider_id = '$sliderId'";
$result2 = mysqli_query($conn, $sql1) or die("Query Failed");
$row = mysqli_fetch_assoc($result2);
unlink("upload/".$row['img_url']);

 $sql = " DELETE FROM slider WHERE slider_id='$sliderId' ";
 $result = mysqli_query($conn, $sql);
 if ($result) {
     header("Location: slider.php");
     SuccessAlert("Image delete sucessfull");
 }
?>