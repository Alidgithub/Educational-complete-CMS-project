<?php include "header.php"; ?>
  <div id="admin-content">
      <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <h1 class="admin-heading">Add New Teacher</h1>
             </div>
              <div class="col-md-offset-3 col-md-6">
                  <!-- Form -->
                  <form  action="action/admin-action.php" method="POST" enctype="multipart/form-data">
                      <div class="form-group">
                          <label for="post_title">Name</label>
                          <input type="text" name="name" class="form-control" placeholder="Name">
                      </div>
                      <div class="form-group">
                          <label for="post_title">Subject</label>
                          <input type="text" name="subject" class="form-control" placeholder="Subject">
                      </div>
                      <div class="form-group">
                          <label for="post_title">Facebook profile link</label>
                          <input type="text" name="fbLink" class="form-control" placeholder="Optional">
                      </div>
                      <div class="form-group">
                          <label for="post_title">twitter profile link</label>
                          <input type="text" name="twitterLink" class="form-control" placeholder="Optional">
                      </div>
                      <div class="form-group">
                          <label for="exampleInputPassword1">About Himself</label>
                          <textarea name="about_teacher" class="form-control" rows="5" placeholder="Tell me about yourself"></textarea>
                      </div>
                      <div class="form-group">
                          <label for="exampleInputPassword1">Post image</label>
                          <input type="file" name="fileToUpload" >
                      </div>
                      <input type="submit" name="addTeacher" class="btn btn-primary" value="Save" required />
                  </form>
                  <!--/Form -->
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
