<?php include "header.php"; ?>
  <div id="admin-content">
      <div class="container">
          <div class="row">
              <div class="col-md-7">
                  <h1 class="admin-heading">Gallery</h1>
              </div>
              <div class="col-md-2">
                  <a class="add-new" href="photo.php">Photo</a>
              </div>
               <div class="col-md-3">
                  <a class="add-new" href="photo-category.php">Photo Catergory</a>
              </div>
              
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
