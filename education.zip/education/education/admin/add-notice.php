<?php include "header.php"; ?>
  <div id="admin-content">
      <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <h1 class="admin-heading">Add New Notice</h1>
             </div>
              <div class="col-md-offset-3 col-md-6">
                  <!-- Form -->
                  <form  action="action/admin-action.php" method="POST" enctype="multipart/form-data">
                      <div class="form-group">
                          <label for="notice_title">Title</label>
                          <input type="text" name="notice_title" class="form-control">
                      </div>
                      <div class="form-group">
                          <label for="notice_date">Date</label>
                          <input type="date" name="notice_date" class="form-control">
                      </div>
                      <div class="form-group">
                          <label for="notice_description"> Description</label>
                          <textarea name="notice_description" class="form-control" rows="5"></textarea>
                      </div>
                      <input type="submit" name="add_notice" class="btn btn-primary" value="Save" required />
                  </form>
                  <!--/Form -->
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
