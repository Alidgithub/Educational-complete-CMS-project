<?php
include "header.php";
include "action/config.php";
if (isset($_GET['img_id'])) {
$img_id = $_GET['img_id'];
 }else{
  header("Location: photo.php");
 }
$sql2 = "SELECT * FROM gallery g LEFT JOIN photo_category pc ON g.photo_cat_id = pc.id WHERE g.photo_id = '$img_id' ";
$result2 = mysqli_query($conn, $sql2);
$row2 = mysqli_fetch_assoc($result2);
?>
  <div id="admin-content">
      <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <h1 class="admin-heading">Update Photo</h1>
             </div>
              <div class="col-md-offset-3 col-md-6">
                  <!-- Form -->
                  <form  action="action/admin-action.php" method="POST" enctype="multipart/form-data">
                      <div class="form-group">
                        <input type="hidden" name="post_img_id"  class="form-control" value="<?php echo $row2['photo_id']; ?>">
                     </div>
                      <div class="form-group">
                          <label for="post_title">Title</label>
                          <input type="text" name="image_title" class="form-control" value="<?php echo $row2['tittle']; ?>">
                      </div>
                      <div class="form-group">
                          <label for="exampleInputPassword1">Category</label>
                          <select name="category" class="form-control">
                          <option disabled selected> Select Category</option>
                          <?php
                          $sql = "SELECT id, category_name FROM photo_category ";
                          $result = mysqli_query($conn, $sql);
                          if (mysqli_num_rows($result) > 0 ) {
                            while ($row = mysqli_fetch_assoc($result)) {
                              if ($row['id'] == $row2['photo_cat_id']) {
                                $selected = "selected";
                              }else{
                                $selected = "";
                              }
                            echo "<option $selected value='{$row['id']}'>{$row['category_name']} </option>";
                            }
                          }
                          ?>
                          </select>
                      </div>
                      <div class="form-group">
                          <label for="">Post image</label>
                          <input type="file" name="new_image" >
                          <img  src="upload/<?php echo $row2['image_url']; ?>" height="160px">
                          <input type="hidden" name="old_image" value="<?php echo $row2['image_url']; ?>" >
                      </div>
                      <input type="submit" name="update_img" class="btn btn-primary" value="Update" required />
                  </form>
                  <!--/Form -->
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
