<?php 
include "header.php"; 
include "action/function.php";
include "action/config.php";
if (!isset($_GET['courseId']) || empty($_GET['courseId'])) {
  header("Location: courses.php");
}
$courseId = $_GET['courseId'];
$sql = "SELECT * FROM courses WHERE course_id = '$courseId' "; 
 $result = mysqli_query($conn, $sql);
 $row = mysqli_fetch_assoc($result);
?>
  <div id="admin-content">
      <div class="container">
         <div class="row">
             <div class="col-md-12">
                 <h1 class="admin-heading">Update Course</h1>
             </div>
              <div class="col-md-offset-3 col-md-6">
                  <!-- Form -->
                  <form  action="action/admin-action.php" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
                    <input type="hidden" name="course_id" value="<?php echo $row['course_id']; ?>">
                      <div class="form-group">
                          <label for="Course name">Course name</label>
                          <input type="text" value="<?php echo $row['course_name']; ?>" name="course_name" class="form-control">
                      </div>
                      <div class="form-group">
                          <label for="Admission fees">Admission fees</label>
                          <input type="number" value="<?php echo $row['admission_fee']; ?>" name="admission_fees" class="form-control">
                      </div>
                      <div class="form-group">
                          <label for="Duration">Duration</label>
                          <input type="number" value="<?php echo $row['duration']; ?>" name="duration" class="form-control">
                      </div>
                      <div class="form-group">
                          <label for="Total fees">Total fees</label>
                          <input type="number" value="<?php echo $row['total_fees']; ?>" name="total_fees" class="form-control">
                      </div>
                        <div class="form-group">
                          <label for="description"> Description</label>
                          <textarea name="description" class="form-control" rows="4"><?php echo $row['description']; ?></textarea>
                      </div>
                      <div class="form-group">
                          <label for="exampleInputPassword1">Course reletade image</label>
                          <input type="file" name="update_new_image">
                          <img src="upload/course/<?php echo $row['img_url'] ?>" height="150px">
                      </div>
                      <input type="submit" name="update_course" class="btn btn-primary" value="Update" required />
                  </form>
                  <!--/Form -->
              </div>
          </div>
      </div>
  </div>
<?php include "footer.php"; ?>
